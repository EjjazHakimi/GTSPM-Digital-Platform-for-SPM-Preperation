-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 16, 2024 at 10:38 PM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gtspm`
--

-- --------------------------------------------------------

--
-- Table structure for table `educator`
--

DROP TABLE IF EXISTS `educator`;
CREATE TABLE IF NOT EXISTS `educator` (
  `EducatorID` varchar(12) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  PRIMARY KEY (`EducatorID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `educator`
--

INSERT INTO `educator` (`EducatorID`, `Name`, `Gender`, `Username`, `Password`, `Email`, `Phone`) VALUES
('ED000', 'Gaurav', 'Male', 'gman123', '123', 'gman@gmail.com', '0123454566'),
('ED123', 'Ejjaz', 'Male', 'ejjancheese', '123', 'ejjancheese@gmail.com', '0123879292'),
('ED8850', 'Nash', 'Male', 'nashran', '456', 'nash@gmail.com', '012 387 9292');

-- --------------------------------------------------------

--
-- Table structure for table `materials`
--

DROP TABLE IF EXISTS `materials`;
CREATE TABLE IF NOT EXISTS `materials` (
  `MaterialsID` int NOT NULL AUTO_INCREMENT,
  `EducatorID` varchar(12) NOT NULL,
  `SubjectID` int NOT NULL,
  `Type` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `FilePath` varchar(255) NOT NULL,
  `upload_date` timestamp NOT NULL,
  `Title` varchar(255) NOT NULL,
  PRIMARY KEY (`MaterialsID`),
  KEY `EducatorID` (`EducatorID`),
  KEY `SubjectID` (`SubjectID`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `materials`
--

INSERT INTO `materials` (`MaterialsID`, `EducatorID`, `SubjectID`, `Type`, `name`, `FilePath`, `upload_date`, `Title`) VALUES
(22, 'ED8850', 1, 'application/pdf', 'Black Box vs White Box.pdf', 'fileupload/Black Box vs White Box.pdf', '2024-12-16 14:31:50', 'Black Box vs White Box'),
(23, 'ED8850', 2, 'application/pdf', 'Review of Laravel.pdf', 'fileupload/Review of Laravel.pdf', '2024-12-16 22:15:07', 'Laravel');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
CREATE TABLE IF NOT EXISTS `question` (
  `QuizID` int NOT NULL AUTO_INCREMENT,
  `SetID` int NOT NULL,
  `QuestionText` varchar(255) NOT NULL,
  `ChoiceA` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ChoiceB` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ChoiceC` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `ChoiceD` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `CorrectAnswer` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Score` int NOT NULL,
  PRIMARY KEY (`QuizID`),
  KEY `SetID` (`SetID`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`QuizID`, `SetID`, `QuestionText`, `ChoiceA`, `ChoiceB`, `ChoiceC`, `ChoiceD`, `CorrectAnswer`, `Score`) VALUES
(18, 7, '1. Simplify  12 + 7 × 3 − 5 ', '26', '28', '34', '36', 'b', 1),
(19, 7, '2. Solve for 𝑥:  2𝑥 + 5 = 15 ', '5', '7.5', '10', '30', 'a', 1),
(20, 7, '3. What is the area of a triangle with base 8 cm and height 5 cm?', '20 cm²', '30 cm²', '40 cm²', '50 cm²', 'a', 1),
(21, 7, '4. What is 45% of 200?', '45', '90', '135', '180', 'b', 1),
(22, 7, '5. Solve for  𝑦:  3𝑦 − 7 = 11:', '3', '6', '7', '9', 'b', 1),
(23, 7, '6. Find the next number in the sequence: 2, 4, 8, 16, ...', '24', '32', '64', '128', 'b', 1),
(24, 7, '7. A shopkeeper buys an item for $50 and sells it for $65. What is the percentage profit?', '20%', '25%', '30%', '35%', 'c', 1),
(25, 7, '8. If a car travels 60 km in 1 hour, how far will it travel in 2.5 hours?', '120 km', '150 km', '180 km', '240 km', 'b', 1),
(26, 7, '9. Simplify  ( 5𝑥 + 3 ) + ( 2𝑥 − 7 ):', '7𝑥 − 4 ', '7𝑥 + 10 ', '10𝑥 − 4', '7𝑥 − 10', 'a', 1),
(27, 7, '10. What is the probability of rolling a 3 on a fair six-sided die?', '1/2', '1/3', '1/6', '1/12', 'c', 1);

-- --------------------------------------------------------

--
-- Table structure for table `quizset`
--

DROP TABLE IF EXISTS `quizset`;
CREATE TABLE IF NOT EXISTS `quizset` (
  `SetID` int NOT NULL AUTO_INCREMENT,
  `EducatorID` varchar(12) NOT NULL,
  `SubjectID` int NOT NULL,
  `Time` time NOT NULL,
  PRIMARY KEY (`SetID`),
  KEY `EducatorID` (`EducatorID`),
  KEY `SubjectID` (`SubjectID`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `quizset`
--

INSERT INTO `quizset` (`SetID`, `EducatorID`, `SubjectID`, `Time`) VALUES
(4, 'ED123', 4, '00:45:00'),
(7, 'ED8850', 5, '01:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `StudentID` varchar(12) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Stream` varchar(10) NOT NULL,
  `Grade` int NOT NULL,
  `SchoolYear` int NOT NULL,
  `Avatar` varchar(255) NOT NULL,
  PRIMARY KEY (`StudentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`StudentID`, `Username`, `Password`, `Email`, `Name`, `Stream`, `Grade`, `SchoolYear`, `Avatar`) VALUES
('ST4837', 'tengkuabdullah', '123', 'tengku@gmail.com', 'Tengku', 'Art', 5, 2020, ''),
('ST9384', 'ejjancheese', '123', 'ejjan@gmail.com', 'Ejjaz', 'Science', 5, 2020, 'A 2.png');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

DROP TABLE IF EXISTS `subject`;
CREATE TABLE IF NOT EXISTS `subject` (
  `SubjectID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Stream` varchar(50) NOT NULL,
  PRIMARY KEY (`SubjectID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`SubjectID`, `Name`, `Stream`) VALUES
(1, 'Physics', 'Science'),
(2, 'Chemistry', 'Science'),
(4, 'Ekonomi', 'Art'),
(5, 'Maths', 'Science');

-- --------------------------------------------------------

--
-- Table structure for table `summary`
--

DROP TABLE IF EXISTS `summary`;
CREATE TABLE IF NOT EXISTS `summary` (
  `SummaryID` int NOT NULL AUTO_INCREMENT,
  `StudentID` varchar(12) NOT NULL,
  `SetID` int NOT NULL,
  `Time` time NOT NULL,
  `TotalScore` int NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`SummaryID`),
  KEY `StudentID` (`StudentID`),
  KEY `SetID` (`SetID`)
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `summary`
--

INSERT INTO `summary` (`SummaryID`, `StudentID`, `SetID`, `Time`, `TotalScore`, `Date`) VALUES
(112, 'ST9384', 7, '00:00:03', 1, '2024-12-16'),
(114, 'ST4837', 7, '00:00:03', 1, '2024-12-16'),
(115, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(116, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(117, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(118, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(119, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(120, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(121, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(122, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(123, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(124, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(125, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(126, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(127, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(128, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(129, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(130, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(131, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(132, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(133, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(134, 'ST9384', 7, '00:00:13', 0, '2024-12-16'),
(135, 'ST9384', 7, '00:00:31', 8, '2024-12-16');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `materials`
--
ALTER TABLE `materials`
  ADD CONSTRAINT `materials_ibfk_1` FOREIGN KEY (`EducatorID`) REFERENCES `educator` (`EducatorID`),
  ADD CONSTRAINT `materials_ibfk_2` FOREIGN KEY (`SubjectID`) REFERENCES `subject` (`SubjectID`);

--
-- Constraints for table `question`
--
ALTER TABLE `question`
  ADD CONSTRAINT `question_ibfk_1` FOREIGN KEY (`SetID`) REFERENCES `quizset` (`SetID`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Constraints for table `quizset`
--
ALTER TABLE `quizset`
  ADD CONSTRAINT `quizset_ibfk_1` FOREIGN KEY (`EducatorID`) REFERENCES `educator` (`EducatorID`) ON DELETE CASCADE,
  ADD CONSTRAINT `quizset_ibfk_2` FOREIGN KEY (`SubjectID`) REFERENCES `subject` (`SubjectID`) ON DELETE CASCADE;

--
-- Constraints for table `summary`
--
ALTER TABLE `summary`
  ADD CONSTRAINT `summary_ibfk_1` FOREIGN KEY (`StudentID`) REFERENCES `student` (`StudentID`) ON DELETE CASCADE,
  ADD CONSTRAINT `summary_ibfk_2` FOREIGN KEY (`SetID`) REFERENCES `quizset` (`SetID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
