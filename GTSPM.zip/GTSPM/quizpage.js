document.getElementById('add-question-btn').addEventListener('click', function () {
    const questionsContainer = document.getElementById('questions-container');
    const questionCount = questionsContainer.children.length + 1;

    const newQuestionBlock = document.createElement('div');
    newQuestionBlock.classList.add('question-block');
    newQuestionBlock.innerHTML = `
        <div class="question-header">
            <h3>Question ${questionCount}</h3>
            <div class="question-actions">
                <button type="button" class="btn btn-danger btn-sm remove-question" data-question-number="${questionCount}">
                    <i class="fas fa-trash"></i> Remove
                </button>
            </div>
        </div>

        <div class="form-group">
            <label>Question Text</label>
            <input 
                type="text" 
                class="form-control"
                id="q${questionCount}_text" 
                placeholder="Enter your question"
                required
            >
        </div>

        <div class="form-group">
            <label>Answers</label>
            <div class="answer-option">
                <input type="radio" name="q${questionCount}_correct" value="a">A
                <input 
                    type="text" 
                    class="form-control" 
                    placeholder="Option A"
                    required
                >
            </div>
            <div class="answer-option">
                <input type="radio" name="q${questionCount}_correct" value="b">B
                <input 
                    type="text" 
                    class="form-control" 
                    placeholder="Option B"
                    required
                >
            </div>
            <div class="answer-option">
                <input type="radio" name="q${questionCount}_correct" value="c">C
                <input 
                    type="text" 
                    class="form-control" 
                    placeholder="Option C"
                    required
                >
            </div>
            <div class="answer-option">
                <input type="radio" name="q${questionCount}_correct" value="d">D
                <input 
                    type="text" 
                    class="form-control" 
                    placeholder="Option D"
                    required
                >
            </div>
        </div>

        <div class="form-group">
            <label>Points for this Question</label>
            <input 
                type="number" 
                class="form-control" 
                id="q${questionCount}_points"
                placeholder="Enter points"
                min="1"
                value="1"
                required
            >
        </div>
    `;
    console.log(questionCount);

    questionsContainer.appendChild(newQuestionBlock);
    newQuestionBlock.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
    });

    // Add event listener for remove button
    const deleteButton = newQuestionBlock.querySelector('.remove-question');
    deleteButton.addEventListener('click', function () {
        questionsContainer.removeChild(newQuestionBlock);
        updateQuestionNumbers();
    });
});

// Update question numbers dynamically after removing a question
function updateQuestionNumbers() {
    const questionsContainer = document.getElementById('questions-container');
    const questionBlocks = questionsContainer.querySelectorAll('.question-block');

    questionBlocks.forEach((block, index) => {
        const questionNumber = index + 1; // Start numbering from 1
        const questionHeader = block.querySelector('h3');
        questionHeader.textContent = `Question ${questionNumber}`;

        // Update the IDs for input fields
        const questionTextInput = block.querySelector('input[type="text"]');
        questionTextInput.id = `q${questionNumber}_text`;

        const pointsInput = block.querySelector('input[type="number"]');
        pointsInput.id = `q${questionNumber}_points`;

        // Update the radio button names
        const radioInputs = block.querySelectorAll('input[type="radio"]');
        radioInputs.forEach((radio) => {
            radio.name = `q${questionNumber}_correct`;
        });
    });
}

document.getElementById('quiz-creation-form').addEventListener('submit', function (e) {
    e.preventDefault();

    // Gather data to submit
    const questionsContainer = document.getElementById('questions-container');
    const questionBlocks = questionsContainer.querySelectorAll('.question-block');
    const quizData = [];

    const subjectID = document.getElementById('subject-select').value;

    const hours = parseInt(document.getElementById("hours").value);
    const minutes = parseInt(document.getElementById("minutes").value);
    const seconds = parseInt(document.getElementById("seconds").value);

    // Format the time as HH:MM:SS
    const formattedTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

    // You can now use formattedTime to insert into your database
    console.log(formattedTime); // Output: 01:01:01


    for (let i = 0; i < questionBlocks.length; i++) {
        const block = questionBlocks[i]; // Get the current question block

        // Get the question text
        const questionText = block.querySelector(`#q${i + 1}_text`).value;

        // Collect all options
        const options = block.querySelectorAll('.answer-option input[type="text"]');

        // Get the correct option
        const correctOption = block.querySelector(`input[name="q${i + 1}_correct"]:checked`);

        const pointsInput = block.querySelector(`#q${i + 1}_points`).value;
        // console.log(`Points for Question ${i + 1}:`, pointsInput); // Log points to the console


        // Add to quizData array
        quizData.push({
            questionText: questionText,
            ChoiceA: options[0]?.value || '',
            ChoiceB: options[1]?.value || '',
            ChoiceC: options[2]?.value || '',
            ChoiceD: options[3]?.value || '',
            correctOption: correctOption ? correctOption.value : null,
            pointsInput: pointsInput,
        });
    }
    const payload = {
        subjectID: subjectID,
        Questions: quizData,
        timeLimit:formattedTime,
    };
    // uploadQuiz(payload)

    console.log(payload); // Log the collected data for testing
    checkQuiz(payload);

    // Submit the data
    // submitQuizData(quizData);
});
function checkQuiz(payload){
    const selectedSubjectID = payload.subjectID;
    var checkRequest = new XMLHttpRequest();
    checkRequest.open('GET', 'checkQuiz.php?subjectID=' + selectedSubjectID, true);
    checkRequest.send();
    checkRequest.onload = function () {
        if (checkRequest.status == 200) {
            const response = JSON.parse(checkRequest.responseText);
            if (response.exists){
                if(confirm("There is an existing quiz for this subject, are you want to overwrite it?")){
                    uploadQuiz(payload);
                }else{
                    alert('Quiz creation canceled');
                    closeForm();
                }
            }
        } else {
            // No quiz exists, proceed with creating the quiz
            uploadQuiz(payload);
    }; 
};
}

function uploadQuiz(payload) {
    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Set up the request
    xhr.open('POST', 'uploadQuiz.php', true);
    xhr.setRequestHeader('Content-Type', 'application/json'); // Indicate JSON data

    // Handle the response
    xhr.onload = function () {
        if (xhr.status === 200) {
            try {
                const response = JSON.parse(xhr.responseText); // Parse the JSON response
                if (response.success) {
                    alert('Quiz uploaded successfully!');
                    window.location.href = 'quiz-page.php';
                } else {
                    alert('Failed to upload quiz: ' + (response.message || 'Unknown error.'));
                }
            } catch (e) {
                console.error('Error parsing response:', e);
                alert('Unexpected response from the server.');
            }
        } else {
            console.error('HTTP Error:', xhr.status, xhr.statusText);
            alert('Failed to upload quiz. Please try again.');
        }
    };

    // Handle network errors
    xhr.onerror = function () {
        console.error('Network Error');
        alert('A network error occurred while uploading the quiz.');
    };

    // Send the payload as JSON
    xhr.send(JSON.stringify(payload));
}

function getSelectedStream(dropdown) {
    var selectedStream = dropdown.value; // Get the selected stream value

    // Create an XMLHttpRequest object to send the selected stream to the PHP file
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'getSubject.php?stream=' + selectedStream, true);
    xhr.send(); // Send the request to the server
    // When the server response is received, update the subject dropdown
    xhr.onload = function () {
        if (xhr.status == 200) {
            document.getElementById('subject-select').innerHTML = xhr.responseText;
        } else {
            console.error("Failed to fetch subjects");
        }
    };
}

function quizForm() {
    document.getElementById('container').style.display = "none";
    document.getElementById('create-quiz-section').style.display = "block";
}

function closeForm() {
    if (confirm("Are you sure want to cancel quiz creation, your work will nor be saved")) {
        document.getElementById('quiz-creation-form').reset();
        document.getElementById('subject-select').innerHTML = '<option value="" disabled selected>Select Subject</option>';
        document.getElementById('container').style.display = "block";
        document.getElementById('create-quiz-section').style.display = "none";
    }
}

function toggleProfileMenu(event) {
    event.stopPropagation();
    const profileDropdown = document.querySelector('.profile-dropdown');
    const isActive = profileDropdown.classList.toggle('active');
    const toggleButton = document.querySelector('.profile-toggle');
    toggleButton.setAttribute('aria-expanded', isActive);

    document.addEventListener('click', function closeMenu(e) {
        if (!e.target.closest('.profile')) {
            profileDropdown.classList.remove('active');
            toggleButton.setAttribute('aria-expanded', false);
            document.removeEventListener('click', closeMenu);
        }
    });
}

