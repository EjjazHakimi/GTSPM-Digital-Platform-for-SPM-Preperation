<?php
// Code Done By: Ejjaz Hakimi bin Mohamad Azan TP073318
session_start();

$conn = include("conn.php");



if (!isset($_SESSION['answers']) || empty($_SESSION['answers'])) {
    die("No answers submitted. Please complete the quiz.");
}

if (!isset($_SESSION['Subject']) || !isset($_SESSION['Stream'])) {
    die("Subject or Stream information is missing.");
}

$userID = $_SESSION['user_id'];
$username = $_SESSION['user_name'];
$selectedStream = isset($_SESSION['Stream']) ? $_SESSION['Stream'] : (isset($_GET['Stream']) ? $_GET['Stream'] : '');
$selectedSubject = isset($_SESSION['Subject']) ? $_SESSION['Subject'] : (isset($_GET['Subject']) ? $_GET['Subject'] : '');

// Gathering SubjectID,from the subject table based on both subject and stream session variable
$sql = "SELECT SubjectId FROM subject WHERE Name = ? AND Stream = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $selectedSubject, $selectedStream);
$stmt->execute();
$subjectResult = $stmt->get_result();

if ($subjectResult->num_rows == 0) {
    die("No matching subject found for the selected stream and subject.");
}

$subjectData = $subjectResult->fetch_assoc();
$subjectID = $subjectData['SubjectId'];


// Gathering SetID, Time from the quizset table based on the SubjectID gathered earlier
$sql = "SELECT SetID, Time FROM quizset WHERE SubjectID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $subjectID);
$stmt->execute();
$setResult = $stmt->get_result();

if ($setResult->num_rows == 0) {
    die("No quiz set found for the selected subject.");
}

$setData = $setResult->fetch_assoc();
$setID = $setData['SetID'];
$allocatedTime = $setData['Time'];

// Gathering QuizID, CorrectAnswer & Score from the question table based on the SetID gathered earlier
$sql = "SELECT QuizID, CorrectAnswer, Score FROM question WHERE SetID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $setID);
$stmt->execute();
$questionResult = $stmt->get_result();

if ($questionResult->num_rows == 0) {
    die("No questions found for the quiz set.");
}

// Storing all answers and scores into an array
$correctAnswers = [];
$questionScores = [];
while ($row = $questionResult->fetch_assoc()) {
    $correctAnswers[$row['QuizID']] = $row['CorrectAnswer'];
    $questionScores[$row['QuizID']] = $row['Score'];
}

// Comparing student answers with correct answers
$userAnswers = $_SESSION['answers']; 
$userAnswers = array_map('strtolower', $userAnswers);
$correctCount = 0;
$totalScore = 0;

$quizIDs = array_keys($correctAnswers); // Get the QuizIDs in order from $correctAnswers

foreach ($quizIDs as $index => $quizID) {
    // Check if there's a user answer at the current index
    if (isset($userAnswers[$index]) && $userAnswers[$index] !== null && $userAnswers[$index] !== "null") {
        $userAnswer = $userAnswers[$index]; // Get the user's answer
        $correctAnswer = $correctAnswers[$quizID]; // Get the correct answer for the QuizID

        if ($userAnswer === $correctAnswer) {
            $correctCount++; // Increment correct count
            $totalScore += $questionScores[$quizID]; // Add the score for the correct answer
        }
    }
}

// Generating score
$totalQuestions = count($correctAnswers);
$maxPossibleScore = array_sum($questionScores);
$scorePercentage = round(($totalScore / $maxPossibleScore) * 100, 2);

// Convert the quiz time from HH:MM:SS to seconds
list($hours, $minutes, $seconds) = explode(":", $allocatedTime);
$totalAllocatedTimeInSeconds = ($hours * 3600) + ($minutes * 60) + $seconds;

$remainingTime = isset($_SESSION['remaining_time']) ? $_SESSION['remaining_time'] : "00:00:00";

//Convert the remaining time from HH:MM:SS to seconds
list($remHours, $remMinutes, $remSeconds) = explode(":", $remainingTime);
$remainingTimeInSeconds = ($remHours * 3600) + ($remMinutes * 60) + $remSeconds;

// Calculate the time spent to complete quiz
$timeSpentInSeconds = $totalAllocatedTimeInSeconds - $remainingTimeInSeconds;

// Format the time spent into HH:MM:SS
$hoursSpent = floor($timeSpentInSeconds / 3600);
$minutesSpent = floor(($timeSpentInSeconds % 3600) / 60);
$secondsSpent = $timeSpentInSeconds % 60;

$timeSpentFormatted = sprintf("%02d:%02d:%02d", $hoursSpent, $minutesSpent, $secondsSpent);

$currentDate = date('Y-m-d');


$sql = "INSERT INTO summary(StudentID, SetID, Time, TotalScore, Date) VALUES ('$userID',$setID,'$timeSpentFormatted',$totalScore, '$currentDate')";

$conn->query($sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="RevisionCornerResults.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100..700;1,100..700&family=League+Spartan:wght@100..900&family=Montserrat:ital,wght@0,100..900;1,100..900&family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>RevisionCornerResults</title>

</head>
<body>
<section class="header">
    <nav>
    <a href="homepage.php"><img src="images/GTSPM.png" width="110" height="110"></a>
        <div class="nav-menu" id="navMenu">
            <i class="fa fa-times" onclick="hideMenu()"></i>
            <ul>
                <li><a href="homepage.php">HOME</a></li>
                <li><a href="RevisionCornerMainPage.php">Revision Corner</a></li>
                <li><a href="summary.php">Progress Report</a></li>
                <li><a href="homepage.php#targetDiv">About</a></li>
                <li><a href="ProfilePage.php"><img src="images/profile.png" width="40" height="40"></a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
    </nav> 
</section>
<section class="subject-select-box">
    <h1>Revision Corner</h1>
    <div class="select-menu1">
        <!-- Submit button to go back to view.php with selected values -->
        <form onsubmit="return validateForm() && confirmUpdate()" method="POST" action="view.php" id="revision-form">
            <input type="hidden" name="Stream" id="hidden-stream" value="<?php echo $selectedStream; ?>">
            <input type="hidden" name="Subject" id="hidden-subject" value="<?php echo $selectedSubject; ?>">
            <input type="submit" value="Update" id = "update-button" name="update">
        </form>
    </div>

    <!-- Form to show selected Stream and Subject options in RevisionCorner -->
    <div class="select-menu">
        <form  method="GET" action="RevisionCorner.php">
        <label for="stream-select" style="font-weight: 900;">Stream:</label>
        <select name="Stream" id="stream-select">
            <option value="">--Select Stream--</option>
            
        </select>

            <label for="subject-select" style="font-weight: 900;">Subject:</label>
            <select name="Subject" id="subject-select">
                <option value="">--Select Subject--</option>
             
            </select>
        </form>
    </div>
</section>
<section class = "results">
    <form>
    <h1> Nice Try <h1> <br>
    <h3> Username: <?php echo $username ?> <h3> <br>
    <h3> Quiz: <?php echo $selectedSubject ?> <h3> <br>
    <h3> Score: <?php echo $scorePercentage ?>% <h3> <br>
    <h3> Time: <?php echo $timeSpentFormatted ?> <h3> <br>
    <button type="submit" name="return" formaction="RevisionCornerMainPage.php" id = "returnbut"> Return </button>
    </form>
</section>
<section class="footer">
        <h4>About Us</h4>
        <a href="homepage.php"><img src="images/GTSPM.png" width = "110" height="110"></a>
        <p>GTSPM is your ultimate learning companion for SPM success, offering interactive quizzes and comprehensive notes tailored to the SPM syllabus.<br> Designed to make studying engaging and effective, we empower students to excel in their exams with confidence.</p>
        <div class="icons">
            <i class="fa fa-facebook"></i>
            <i class="fa fa-twitter"></i>
            <i class="fa fa-instagram"></i>   
        </div>
        <p><i class="fa fa-copyright"></i>2024 GTSPM. All rights reserved</p>
</section>
</body>

<script>
        var navMenu = document.getElementById("navMenu");
        function showMenu(){
            navMenu.style.right="0";
        }
        function hideMenu(){
            navMenu.style.right="-200px";
        }
</script>


</html>

<script>
    // Track selected values
    const selectedStream = "<?php echo $selectedStream; ?>";
    const selectedSubject = "<?php echo $selectedSubject; ?>";
    console.log("Selected Stream:", selectedStream);
    console.log("Selected Subject:", selectedSubject);

    // Populate stream and subject dropdowns dynamically
    fetch('FetchSubjectsDropDown.php')
        .then(response => response.json())
        .then(subjectdata => {
            const streamSelect = document.getElementById("stream-select");
            const subjectSelect = document.getElementById("subject-select");

            if (!subjectdata || Object.keys(subjectdata).length === 0) {
                alert("No streams or subjects found.");
                return;
            }

            // Populate Stream dropdown
            streamSelect.innerHTML = "<option value=''>--Select Stream--</option>";
            for (const stream in subjectdata) {
                const option = document.createElement("option");
                option.value = stream;
                option.textContent = stream.replace(/-/g, " ");
                if (stream === selectedStream) {
                    option.selected = true; // Preselect stream if it's the selected one
                }
                streamSelect.appendChild(option);
            }

            // Populate Subject dropdown based on selected Stream
            if (selectedStream !== "") {
                updateSubjects(selectedStream);
            }

            // Update Subject dropdown when Stream changes
            streamSelect.addEventListener("change", function () {
                const selectedStream = this.value;
                updateSubjects(selectedStream);
            });

            function updateSubjects(selectedStream) {
                subjectSelect.innerHTML = "<option value=''>--Select Subject--</option>";

                const availableSubjects = subjectdata[selectedStream] || [];

                availableSubjects.forEach(subject => {
                    const option = document.createElement("option");
                    option.value = subject.replace(/\s+/g, "-");
                    option.textContent = subject;
                    if (subject === selectedSubject.replace(/-/g, " ")) {
                        option.selected = true; // Preselect subject if it's the selected one
                    }
                    subjectSelect.appendChild(option);
                });
            }
        })
        .catch(error => {
            console.error("Error fetching data:", error);
            alert("Failed to load dropdown options. Please try again later.");
        });

</script>


