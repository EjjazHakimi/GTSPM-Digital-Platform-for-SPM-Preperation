<?php
// Code Done By: Ejjaz Hakimi bin Mohamad Azan TP073318
session_start();

unset($_SESSION['answers']);
unset($_SESSION['timer']);
unset($_SESSION['remaining_time']);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Save Stream and Subject selections in session
    $_SESSION['Stream'] = $_POST['Stream'];
    $_SESSION['Subject'] = $_POST['Subject'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="RevisionCornerMainPage.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100..700;1,100..700&family=League+Spartan:wght@100..900&family=Montserrat:ital,wght@0,100..900;1,100..900&family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Document</title>
</head>
<body>
<section class="header">
    <nav>
        <a href="homepage.php"><img src="images/GTSPM.png" width="110" height="110"></a>
        <div class="nav-menu" id="navMenu">
        <i class="fa fa-times" onclick="hideMenu()"></i>
            <ul>
                <li><a href="homepage.php">HOME</a></li>
                <li><a href="RevisionCornerMainPage.php">Revision Corner</a></li>
                <li><a href="summary.php">Progress Report</a></li>
                <li><a href="homepage.php#targetDiv">About</a></li>
                <li><a href="ProfilePage.php"><img src="images/profile.png" width="40" height="40"></a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
    </nav> 
</section>

<section class="subject-select-box">
    <h1>Revision Corner</h1>
    <div class="select-menu">
        <!-- Form for "Submit" button to pass values to view.php -->
        <form onsubmit="return validateForm()" method="POST" action="view.php">
            <label for="Stream" style="font-weight: 900;">Stream:</label>
            <select name="Stream" id="stream-select">
                <option value="">--Select Stream--</option>
                <!-- Dynamically populate streams here -->
            </select>

            <label for="Subject" style="font-weight: 900;">Subject:</label>
            <select name="Subject" id="subject-select">
                <option value="">--Select Subject--</option>
                <!-- Dynamically populate subjects here -->
            </select>

            <!-- Submit button to pass selected values -->
            <input type="submit" value="Submit">
        </form>
    </div>
</section>

<section>
    <div class = "infobox1">
        <div id = "infobox1-pic">
            <img src = "images/InfoBox1.png" id = "pic1">
        </div>
        <div class= "infobox1-text">
        </div>
    </div>
        <div class = "infobox2">
        <div id = "infobox2-pic">
            <img src = "images/InfoBox2.png" id = "pic2">
        </div>
        <div class ="infobox2-text">
        </div>
    </div>
    
</section>

<section class="footer">
        <h4>About Us</h4>
        <a href="homepage.php"><img src="images/GTSPM.png" width = "110" height="110"></a>
        <p>GTSPM is your ultimate learning companion for SPM success, offering interactive quizzes and comprehensive notes tailored to the SPM syllabus.<br> Designed to make studying engaging and effective, we empower students to excel in their exams with confidence.</p>
        <div class="icons">
            <i class="fa fa-facebook"></i>
            <i class="fa fa-twitter"></i>
            <i class="fa fa-instagram"></i>   
        </div>
        <p><i class="fa fa-copyright"></i>2024 GTSPM. All rights reserved</p>
</section>

<script>
    function validateForm() {
        const stream = document.getElementById("stream-select").value;
        const subject = document.getElementById("subject-select").value;

        if (!stream || !subject) {
            alert("Please select both a Stream and a Subject.");
            return false;
        }

        return true;
    }
</script>

<script>
    // Fetch and populate dropdowns for Stream and Subject dynamically
    fetch('FetchSubjectsDropDown.php')
        .then(response => response.json())
        .then(subjectdata => {
            const streamSelect = document.getElementById("stream-select");
            const subjectSelect = document.getElementById("subject-select");

            if (!subjectdata || Object.keys(subjectdata).length === 0) {
                alert("No streams or subjects found.");
                return;
            }

            // Populate Stream dropdown
            streamSelect.innerHTML = "<option value=''>--Select Stream--</option>";
            for (const stream in subjectdata) {
                const option = document.createElement("option");
                option.value = stream;
                option.textContent = stream.replace(/-/g, " ");
                streamSelect.appendChild(option);
            }

            // Update Subject dropdown based on selected Stream
            streamSelect.addEventListener("change", function () {
                const selectedStream = this.value;
                updateSubjects(selectedStream);
            });

            function updateSubjects(selectedStream) {
                subjectSelect.innerHTML = "<option value=''>--Select Subject--</option>";

                const availableSubjects = subjectdata[selectedStream] || [];

                availableSubjects.forEach(subject => {
                    const option = document.createElement("option");
                    option.value = subject.replace(/\s+/g, "-");
                    option.textContent = subject;
                    subjectSelect.appendChild(option);
                });
            }
        })
        .catch(error => {
            console.error("Error fetching data:", error);
            alert("Failed to load dropdown options. Please try again later.");
        });
</script>

<script>
        var navMenu = document.getElementById("navMenu");
        function showMenu(){
            navMenu.style.right="0";
        }
        function hideMenu(){
            navMenu.style.right="-200px";
        }
    </script>

</body>
</html>
