<?php

include("conn.php");


$sql = "SELECT Stream, Name FROM subject";
$result = $conn->query($sql);


if (!$result) {
    die(json_encode(["error" => "SQL error: " . $conn->error]));
}

$subjectdata = []; 

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $stream = $row['Stream'];
        $subject = $row['Name'];

   
        $normalizedStream = strtolower(str_replace(" ", "-", $stream));

        $capitalizedStream = ucwords(str_replace("-", " ", $normalizedStream));

        $capitalizedSubject = ucwords(strtolower($subject));


        if (!isset($subjectdata[$capitalizedStream])) {
            $subjectdata[$capitalizedStream] = [];
        }


        $subjectdata[$capitalizedStream][] = $capitalizedSubject;
    }
}


if (empty($subjectdata)) {
    echo json_encode([]);
} else {

    header('Content-Type: application/json'); 
    echo json_encode($subjectdata);
}

$conn->close();
?>
