<?php

include("conn.php");

// Check if the 'id' is provided in the URL
if (isset($_GET['id'])) {
    $materialsID = $_GET['id'];

    // Prepare the query to delete the material
    $delete_query = "DELETE FROM materials WHERE MaterialsID = ?";
    $stmt_delete = $conn->prepare($delete_query);
    $stmt_delete->bind_param("i", $materialsID);

    // Execute the delete query
    if ($stmt_delete->execute()) {
        // Redirect back to the materials page after deletion
        header("Location: learningMaterials.php");
        exit();
    } else {
        echo "Error deleting the material.";
    }

    // Close the statement
    $stmt_delete->close();
} else {
    echo "No material ID specified.";
}

// Close the connection
$conn->close();
?>
