<?php

session_start();

header('Content-Type: application/json');

// Read the JSON payload
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if ($data) {
    // Extract payload details
    $subjectID = $data['subjectID'];
    $questions = $data['Questions'];
    $timeLimit = $data['timeLimit'];

    // Simulate database insertion or processing
    $success = saveQuizToDatabase($subjectID, $questions, $timeLimit); // Replace with your DB logic

    if ($success) {
        echo json_encode(["success" => true, "message" => "Quiz uploaded successfully."]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to upload quiz."]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Invalid input data."]);
}

function saveQuizToDatabase($subjectID, $questions, $timeLimit) {
    include("conn.php");

    // Replace with session variable if available
    $educatorID =$_SESSION['EducatorID']; // Test data for EducatorID

    // Check if a quiz already exists for this subject
    $checkQuizExists = "SELECT * FROM quizset WHERE SubjectID = '$subjectID'";
    $checkQuizExistsResult = mysqli_query($conn, $checkQuizExists);

    if ($checkQuizExistsResult && mysqli_num_rows($checkQuizExistsResult) > 0) {
        // Quiz exists - overwrite the existing one
        $existingQuiz = mysqli_fetch_assoc($checkQuizExistsResult);
        $setID = $existingQuiz['SetID'];

        // Update the quizset table with the new time limit
        $updateQuizSet = "UPDATE quizset SET EducatorID = '$educatorID', Time = '$timeLimit' WHERE SetID = '$setID'";
        if (!mysqli_query($conn, $updateQuizSet)) {
            return false; // Return failure if updating quizset fails
        }

        // Delete old questions for this quiz set
        $deleteQuestions = "DELETE FROM question WHERE SetID = '$setID'";
        if (!mysqli_query($conn, $deleteQuestions)) {
            return false; // Return failure if deleting old questions fails
        }
    } else {
        // Quiz does not exist - insert a new quizset
        $addSetID = "INSERT INTO quizset (EducatorID, SubjectID, Time) VALUES ('$educatorID', '$subjectID', '$timeLimit')";
        if (!mysqli_query($conn, $addSetID)) {
            return false; // Return failure if inserting into quizset fails
        }

        // Retrieve the newly generated SetID
        $setID = mysqli_insert_id($conn);
    }

    // Insert new questions into the question table
    foreach ($questions as $question) {
        $questionText = mysqli_real_escape_string($conn, $question['questionText']);
        $choiceA = mysqli_real_escape_string($conn, $question['ChoiceA']);
        $choiceB = mysqli_real_escape_string($conn, $question['ChoiceB']);
        $choiceC = mysqli_real_escape_string($conn, $question['ChoiceC']);
        $choiceD = mysqli_real_escape_string($conn, $question['ChoiceD']);
        $correctOption = mysqli_real_escape_string($conn, $question['correctOption']);
        $score = intval($question['pointsInput']);

        $insertQuestion = "
            INSERT INTO question (SetID, QuestionText, ChoiceA, ChoiceB, ChoiceC, ChoiceD, CorrectAnswer, Score)
            VALUES ('$setID', '$questionText', '$choiceA', '$choiceB', '$choiceC', '$choiceD', '$correctOption', '$score')
        ";
        if (!mysqli_query($conn, $insertQuestion)) {
            return false; // Return failure if inserting a question fails
        }
    }

    return true; // All operations were successful
}

?>
