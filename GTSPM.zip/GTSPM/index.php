<?php

session_start();

include('conn.php');

if (!isset($_SESSION['EducatorID'])) {
    echo  "<script> alert('Please login to continue !') 
    window.location.href='login.php'
    </script>";
}

$sql = "SELECT SummaryID, StudentID, SetID, Time, TotalScore, Date FROM summary";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Educator Dashboard</title>
    <link rel="stylesheet" href="index.css">
    <script src="script.js" defer></script>
</head>
<body>
<header>
    <nav id="nav-bar">
        <div class="nav-container">
            <div id="div-left">
                <a href="index.php">
                    <img src="Assests/Logo-GTSPM.png" alt="GTSPM Logo" class="logo">
                </a>
            </div>
            <div class="nav-right">
                <ul class="nav-links">
                    <li>
                        <a href="learningMaterials.php" class="nav-btn <?php echo (basename($_SERVER['PHP_SELF']) == 'learningMaterials.php') ? 'active' : ''; ?>">
                            Learning Materials
                        </a>
                    </li>
                    <li>
                        <a href="quiz-page.php" class="nav-btn <?php echo (basename($_SERVER['PHP_SELF']) == 'quiz-page.php') ? 'active' : ''; ?>">
                            Quiz
                        </a>
                    </li>
                    <li>
                        <a href="index.php" class="nav-btn <?php echo (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'active' : ''; ?>">
                            Dashboard
                        </a>
                    </li>
                    <li>
                        <a href="MonitorStudent.php" class="nav-btn <?php echo (basename($_SERVER['PHP_SELF']) == 'MonitorStudent.php') ? 'active' : ''; ?>">
                            Monitor Student
                        </a>
                    </li>
                </ul>

                <div class="profile">
                    <button class="profile-toggle" onclick="toggleProfileMenu(event)" aria-label="Profile Menu">
                        <img src="Assests/profile_icon.jpg" alt="Profile" class="profile-icon">
                    </button>
                    <div class="profile-dropdown">
                        <a href="profile.php">My Profile</a>
                        <a href="settings.php">Settings</a>
                        <a href="logout.php" class="logout">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>
</header>

   <main>
    <h1 class="quick-access" id="quick-text">Quick Access</h1>
    <div id="quick-access" class="quick-access">
        <button id="create-quiz" class="quick-element" data-page="quiz-page.php">Create Quiz</button>
        <button id="upload-material" class="quick-element" data-page="learningMaterials.php">Upload Learning Material</button>
    </div>
    
    <h1 class="recent-quiz-text">Recent Attempted Quizzes</h1>
    <table id="main-page-table">
    <thead>
            <tr>
                <th>SummaryID</th>
                <th>StudentID</th>
                <th>SetID</th>
                <th>Time</th>
                <th>TotalScore</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                // Output data for each row
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>{$row['SummaryID']}</td>
                        <td>{$row['StudentID']}</td>
                        <td>{$row['SetID']}</td>
                        <td>{$row['Time']}</td>
                        <td>{$row['TotalScore']}</td>
                        <td>{$row['Date']}</td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No records found</td></tr>";
            }
            ?>
        </tbody>
    </table>
   </main>
    <footer class="footer">
    <p>&copy; 2024 Learning Management System. All rights reserved.</p>
    </footer>

   <script>
    // Add event listeners for navigation
    document.querySelectorAll('[data-page]').forEach(button => {
        button.addEventListener('click', () => {
            window.location.href = button.getAttribute('data-page');
        });
    });

    function toggleProfileMenu(event) {
    event.stopPropagation();
    const profileDropdown = document.querySelector('.profile-dropdown');
    const isActive = profileDropdown.classList.toggle('active');
    const toggleButton = document.querySelector('.profile-toggle');
    toggleButton.setAttribute('aria-expanded', isActive);

    document.addEventListener('click', function closeMenu(e) {
        if (!e.target.closest('.profile')) {
            profileDropdown.classList.remove('active');
            toggleButton.setAttribute('aria-expanded', false);
            document.removeEventListener('click', closeMenu);
        }
    });
}

   </script>
</body>
</html>