<?php
include("conn.php");

if (isset($_GET['subjectID'])) {
    $subjectID = $_GET['subjectID'];
    $sql = "SELECT COUNT(*) from quizset where SubjectID = '$subjectID'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        // Quiz exists, send a response indicating this
        echo json_encode(['exists' => true]);
    } else {
        // Quiz does not exist
        echo json_encode(['exists' => false]);
    }
}
?>