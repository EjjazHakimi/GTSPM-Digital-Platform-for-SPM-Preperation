<?php
session_start();

// Handle form submission and store selected values in the session
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $_SESSION['Stream'] = $_POST['Stream'] ?? '';  // Set default to empty if not set
    $_SESSION['Subject'] = $_POST['Subject'] ?? '';  // Set default to empty if not set
}

// Get selected stream and subject from session
$selectedStream = $_SESSION['Stream'] ?? '';  
$selectedSubject = $_SESSION['Subject'] ?? '';

$conn = include("conn.php");

$subjects_query = "SELECT * FROM subject";
if (!empty($selectedStream)) {
    $subjects_query .= " WHERE Stream = '" . mysqli_real_escape_string($conn, $selectedStream) . "'";
}
$subjects_result = mysqli_query($conn, $subjects_query);

// SQL query to fetch materials based on filters
$query = "SELECT materials.MaterialsID, materials.Name AS file_name, materials.upload_date, subject.Stream, subject.Name AS subject_name 
          FROM materials 
          JOIN subject ON materials.SubjectID = subject.SubjectID 
          WHERE 1=1";
if (!empty($selectedStream)) {
    $query .= " AND subject.Stream = '" . mysqli_real_escape_string($conn, $selectedStream) . "'";
}
if (!empty($selectedSubject)) {
    $query .= " AND subject.Name = '" . mysqli_real_escape_string($conn, $selectedSubject) . "'";
}

$result = mysqli_query($conn, $query);

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    // Unset the session variables
    unset($_SESSION['answers']);
    
    // Redirect after unsetting the session variables (to avoid resubmission)
    header("Location: view.php");  // Or the desired page
    exit();  // Make sure no further code is executed after the redirect
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="view.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100..700;1,100..700&family=League+Spartan:wght@100..900&family=Montserrat:ital,wght@0,100..900;1,100..900&family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>View Materials</title>
</head>
<body>

<section class="header">
    <nav>
    <a href="homepage.php"><img src="images/GTSPM.png" width="110" height="110"></a>
        <div class="nav-menu" id="navMenu">
            <i class="fa fa-times" onclick="hideMenu()"></i>
            <ul>
                <li><a href="homepage.php">HOME</a></li>
                <li><a href="RevisionCornerMainPage.php">Revision Corner</a></li>
                <li><a href="summary.php">Progress Report</a></li>
                <li><a href="homepage.php#targetDiv">About</a></li>
                <li><a href="ProfilePage.php"><img src="images/profile.png" width="40" height="40"></a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
    </nav> 
</section>

<section class="subject-select-box">
    <h1>Revision Corner</h1>
    <div class="select-menu">
        <!-- Form for "Filter" button to reload the page and pass values -->
        <form onsubmit="return confirmFilter()" method="POST">
            <label for="Stream" style="font-weight: 900;">Stream:</label>
            <select name="Stream" id="stream-select">
                <option value="">--Select Stream--</option>
                <!-- Dynamically populated stream options will go here -->
            </select>

            <label for="Subject" style="font-weight: 900;">Subject:</label>
            <select name="Subject" id="subject-select">
                <option value="">--Select Subject--</option>
                <!-- Dynamically populated subject options will go here -->
            </select>

            <!-- Filter button (reloads the page with selected values) -->
            <input type="submit" value="Filter" id = "FilterButton">
        </form>

        <!-- Form for "Attempt Quiz" button to redirect to RevisionCorner.php with selected values -->
        <form onsubmit= "return confirmAttemptQuiz()" method="POST" action="RevisionCorner.php">
            <input type="hidden" name="Stream" value="<?php echo htmlspecialchars($selectedStream); ?>">
            <input type="hidden" name="Subject" value="<?php echo htmlspecialchars($selectedSubject); ?>">
            <form action="RevisionCorner.php" method="get">
                <input type="submit" value="Attempt Quiz" id="AttemptButton">
            </form>
        </form>
    </div>
</section>

<section>
<br>
<label for ='materials' id ='labelmaterial'> Available Materials </label>
<table name = 'materials'>
    <thead>
        <tr>
            <th>File Name</th>
            <th>Date of Upload</th>
            <th>Stream</th>
            <th>Subject</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php if (mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?= htmlspecialchars($row['file_name']) ?></td>
                    <td><?= htmlspecialchars($row['upload_date']) ?></td>
                    <td><?= htmlspecialchars($row['Stream']) ?></td>
                    <td><?= htmlspecialchars($row['subject_name']) ?></td>
                    <td>
                        <a href="download.php?file_id=<?= $row['MaterialsID'] ?>">Download</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="5">No materials found.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
        </section>


<script>
    function validateForm() {
        const stream = document.getElementById("stream-select").value;
        const subject = document.getElementById("subject-select").value;

        if (!stream || !subject) {
            alert("Please select both a Stream and a Subject.");
            return false;
        }
        return true;
    }
</script>


    
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        // Fetch and populate dropdowns for Stream and Subject dynamically
        fetch('FetchSubjectsDropDown.php')
            .then(response => response.json())
            .then(subjectdata => {
                const streamSelect = document.getElementById("stream-select");
                const subjectSelect = document.getElementById("subject-select");

                if (!subjectdata || Object.keys(subjectdata).length === 0) {
                    alert("No streams or subjects found.");
                    return;
                }

                // Populate Stream dropdown
                streamSelect.innerHTML = "<option value=''>--Select Stream--</option>";
                for (const stream in subjectdata) {
                    const option = document.createElement("option");
                    option.value = stream;
                    option.textContent = stream.replace(/-/g, " ");
                    if (stream === "<?php echo $selectedStream; ?>") {
                        option.selected = true; // Preselect stream if it's the selected one from session
                    }
                    streamSelect.appendChild(option);
                }

                // Populate Subject dropdown based on selected Stream
                if ("<?php echo $selectedStream; ?>" !== "") {
                    updateSubjects("<?php echo $selectedStream; ?>");
                }

                // Update Subject dropdown when Stream changes
                streamSelect.addEventListener("change", function () {
                    const selectedStream = this.value;
                    updateSubjects(selectedStream);
                });

                function updateSubjects(selectedStream) {
                    subjectSelect.innerHTML = "<option value=''>--Select Subject--</option>";

                    const availableSubjects = subjectdata[selectedStream] || [];

                    availableSubjects.forEach(subject => {
                        const option = document.createElement("option");
                        option.value = subject.replace(/\s+/g, "-");
                        option.textContent = subject;
                        if (subject === "<?php echo $selectedSubject; ?>".replace(/-/g, " ")) {
                            option.selected = true; // Preselect subject if it's the selected one from session
                        }
                        subjectSelect.appendChild(option);
                    });
                }
            })
            .catch(error => {
                console.error("Error fetching data:", error);
                alert("Failed to load dropdown options. Please try again later.");
            });
    });

    // Confirm Filter action
    function confirmFilter() {
        return confirm("Are you sure you want to update the selections?");
    }

    // Confirm Attempt Quiz action
    function confirmAttemptQuiz() {
        return confirm("Are you sure you want to attempt the quiz? \n\nIf you have changed the subject or stream value please ensure that the update button has been clicked or else the values will not be updated");
    }
</script>

<script>
        var navMenu = document.getElementById("navMenu");
        function showMenu(){
            navMenu.style.right="0";
        }
        function hideMenu(){
            navMenu.style.right="-200px";
        }
</script>


</body>
</html>
