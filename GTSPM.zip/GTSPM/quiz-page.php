<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create New Quiz - Educator Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="quizPage.css">
</head>

<body>
<header>
    <nav id="nav-bar">
        <div class="nav-container">
            <div id="div-left">
                <a href="index.php">
                    <img src="Assests/Logo-GTSPM.png" alt="GTSPM Logo" class="logo">
                </a>
            </div>
            <div class="nav-right">
                <ul class="nav-links">
                    <li>
                        <a href="learningMaterials.php" class="nav-btn <?php echo (basename($_SERVER['PHP_SELF']) == 'learningMaterials.php') ? 'active' : ''; ?>">
                            Learning Materials
                        </a>
                    </li>
                    <li>
                        <a href="quiz-page.php" class="nav-btn <?php echo (basename($_SERVER['PHP_SELF']) == 'quiz-page.php') ? 'active' : ''; ?>">
                            Quiz
                        </a>
                    </li>
                    <li>
                        <a href="index.php" class="nav-btn <?php echo (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'active' : ''; ?>">
                            Dashboard
                        </a>
                    </li>
                    <li>
                        <a href="MonitorStudent.php" class="nav-btn <?php echo (basename($_SERVER['PHP_SELF']) == 'MonitorStudent.php') ? 'active' : ''; ?>">
                            Monitor Student
                        </a>
                    </li>
                </ul>

                <div class="profile">
                    <button class="profile-toggle" onclick="toggleProfileMenu(event)" aria-label="Profile Menu">
                        <img src="Assests/profile_icon.jpg" alt="Profile" class="profile-icon">
                    </button>
                    <div class="profile-dropdown">
                        <a href="profile.php">My Profile</a>
                        <a href="settings.php">Settings</a>
                        <a href="logout.php" class="logout">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>
</header>
    
    <div class="container" id="container">
        <h2 class="section-title">Available Materials</h2>
        <button type="button" class="create-quiz-button" onclick="quizForm()">Create Quiz</button>

        <?php
        include("conn.php");
        $educatorID = $_SESSION['EducatorID'];
        $sql = "SELECT s.Name, qs.Time, qs.SetID FROM quizSet qs INNER JOIN  
                subject s  on qs.SubjectID = s.SubjectID where EducatorID = '$educatorID'";
        $result = mysqli_query($conn, $sql);
        if (!$result) {
            echo "Error: " . mysqli_error($conn);
            return;
        }
        while ($row = mysqli_fetch_assoc($result)) {
            $SetID = $row['SetID'];
            echo '
            <div class="quiz-item">
                <div class="quiz-content">
                    <p>' . htmlspecialchars($row["Name"]) . ' </p>
                    <p>Time Allocated: ' . htmlspecialchars($row["Time"]) . ' </p>
                </div>
                <div class="btn-group">
                    <button class="delete" id = "deleteBtn" value="' . $SetID . '" type="button" onclick="confirmDelete()">Delete</button>
                </div>
            </div>';
        }
        ?>
    </div>


    <div class="CreateContainer create-quiz-section" id="create-quiz-section">
        <div class="quiz-form-header">
            <h1>Create New Quiz</h1>
        </div>
        <form id="quiz-creation-form">
            <div class="form-group">
                <label for="streamDropdown">Stream:</label>
                <select name="stream" id="streamDropdown" class="form-control" onchange="getSelectedStream(this)">
                    <option disabled selected>Select a subject stream</option>
                    <option value="Arts">Art</option>
                    <option value="Science">Science</option>
                </select>
                <label for="subject-select">Subject</label>
                <select name="subject" id="subject-select" name="selectedSubject" class="form-control">
                    <option disabled selected>Select a subject</option>
                </select>
                <div class="time-limit-container">
                    <label>Time Limit:</label>
                    <div class="time-inputs">
                        <div class="time-input">
                            <label for="hours">Hours:</label>
                            <input type="number" id="hours" min="0" >
                        </div>
                        <div class="time-input">
                            <label for="minutes">Minutes:</label>
                            <input type="number" id="minutes" min="0">
                        </div>
                        <div class="time-input">
                            <label for="seconds">Seconds:</label>
                            <input type="number" id="seconds" min="0">
                        </div>
                    </div>
                </div>
            </div>
            <div id="questions-container">
                <div class="question-block">
                    <div class="question-header">
                        <h3>Question 1</h3>
                        <div class="question-actions">
                            <button type="button" class="btn btn-danger btn-sm">
                                <i class="fas fa-trash"></i> Remove
                            </button>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Question Text</label>
                        <input type="text" class="form-control" placeholder="Enter your question" id="q1_text" required>
                    </div>

                    <div class="form-group">
                        <label>Answers</label>
                        <div class="answer-option">
                            <input type="radio" name="q1_correct" value="a">A
                            <input type="text" class="form-control" placeholder="Option A" required>
                        </div>
                        <div class="answer-option">
                            <input type="radio" name="q1_correct" value="b">B
                            <input type="text" class="form-control" placeholder="Option B" required>
                        </div>
                        <div class="answer-option">
                            <input type="radio" name="q1_correct" value="c">C
                            <input type="text" class="form-control" placeholder="Option C" required>
                        </div>
                        <div class="answer-option">
                            <input type="radio" name="q1_correct" value="d">D
                            <input type="text" class="form-control" placeholder="Option D" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Points for this Question</label>
                        <input type="number" class="form-control" id= "q1_points" placeholder="Enter points" min="1" value="1" required>
                    </div>
                </div>
            </div>

            <div class="form-actions">
                <button type="button" id="add-question-btn" class="btn btn-secondary">
                    <i class="fas fa-plus"></i> Add Question
                </button>
                <div>
                    <button type="button" class="btn btn-outline mr-2" onclick="closeForm()">
                        Cancel
                    </button>
                    <button type="submit" name="submitBtn" class="btn btn-primary">
                        <i class="fas fa-save" onclick="uploadQuiz()"></i> Save Quiz
                    </button>
                </div>
            </div>
        </form>
    </div>
    <footer class="footer">
        <p>&copy; 2024 Learning Management System. All rights reserved.</p>
    </footer>

    <script src="quizpage.js"></script>
    <script>
        function confirmDelete(){
            if (confirm("Are you sure want to delete this quiz, it is an irreversible action!")){
                var setID = document.getElementById('deleteBtn').value;
                window.location.href = 'deleteQuiz.php?setID=' +setID;
            }
        }

    </script>
</body>

</html>