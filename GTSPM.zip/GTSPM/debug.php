<?php

// Check if ID is provided
if (!isset($_GET['ID'])) {
    header("Content-Type: application/json");
    echo json_encode(["error" => "Invalid Student ID"]);
    exit;
}

// Get the student ID from the query parameter
$studentID = $_GET['ID'];

// Respond with JSON containing the student ID
header("Content-Type: application/json");
echo json_encode(["studentID" => $studentID]);
?>