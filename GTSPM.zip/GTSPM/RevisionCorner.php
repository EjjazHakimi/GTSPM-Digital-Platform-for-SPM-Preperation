<?php
// Code Done By: Ejjaz Hakimi bin Mohamad Azan TP073318
session_start();  // Start the session

// Check if user is logged in
if (!isset($_SESSION['user_id'])){
    echo  "<script> alert('Please login to continue !') 
    window.location.href='homepage.php'
    </script>";
}

// Define both time and remaining time variables
$time = isset($_SESSION['time']) ? $_SESSION['time'] : "00:00:00";
$remaining_time = isset($_POST['remaining_time']) ? $_POST['remaining_time'] :null;

// If remaining time exists, declare remaining time as a session variable
if (isset($_POST['remaining_time'])) {
    $_SESSION['remaining_time'] = $remaining_time;
}

// Initialise the question array for later use
$questions = [];

// Store the selected values in session on form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" ) {
    // Save the selected Stream and Subject in the session
    if (isset($_POST['Stream']) && isset($_POST['Subject'])) {
        $_SESSION['Stream'] = $_POST['Stream'];
        $_SESSION['Subject'] = $_POST['Subject'];
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Loop through the posted answers and store them in the session
    foreach ($_POST as $key => $value) {
        if (strpos($key, 'question-') === 0) {
            // Store the selected answer in the session using the question index as key
            $questionIndex = (int)substr($key, 9); // Extract the question index
            $_SESSION['answers'][$questionIndex] = $value;
        }
    }
}



// Retrieve selected values from session
$selectedStream = isset($_SESSION['Stream']) ? $_SESSION['Stream'] : (isset($_GET['Stream']) ? $_GET['Stream'] : '');
$selectedSubject = isset($_SESSION['Subject']) ? $_SESSION['Subject'] : (isset($_GET['Subject']) ? $_GET['Subject'] : '');


if ($_SERVER["REQUEST_METHOD"] == "POST" || isset($_GET['Stream']) && isset($_GET['Subject'])) {
    include("conn.php");

    $stream = isset($_POST["Stream"]) ? $_POST["Stream"] : (isset($_GET['Stream']) ? $_GET['Stream'] : null);
    $subject = isset($_POST['Subject']) ? $_POST['Subject'] : (isset($_GET['Subject']) ? $_GET['Subject'] : null);

    if ($stream && $subject) {
        // Get the SubjectID based on the selected subject
        $subjectQuery = "SELECT SubjectID FROM subject WHERE Name = ?";
        $stmt = $conn->prepare($subjectQuery);
        $stmt->bind_param("s", $subject);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $subjectData = $result->fetch_assoc();
            $subjectID = $subjectData['SubjectID'];

            // Fetch the timer based on the selected SubjectID
            $timerQuery = "SELECT Time FROM quizset WHERE SubjectID = ?";
            $stmt2 = $conn->prepare($timerQuery);
            $stmt2->bind_param("i", $subjectID);
            $stmt2->execute();
            $timerResult = $stmt2->get_result();

        if ($timerResult->num_rows > 0) {
            $timerData = $timerResult->fetch_assoc();
            $time = $timerData['Time']; // Store the time in the session
            $_SESSION['time'] = $time; // Save the time value in session
            
        }

        

       

            // Fetch SetID from quizset table based on SubjectID
            $quizsetQuery = "SELECT SetID FROM quizset WHERE SubjectID = ?";
            $stmt2 = $conn->prepare($quizsetQuery);
            $stmt2->bind_param("i", $subjectID);
            $stmt2->execute();
            $quizsetResult = $stmt2->get_result();

            if ($quizsetResult->num_rows > 0) {
                $quizsetData = $quizsetResult->fetch_assoc();
                $setID = $quizsetData['SetID'];

                // Fetch questions related to the SetID
                $questionQuery = "SELECT QuestionText, ChoiceA, ChoiceB, ChoiceC, ChoiceD, CorrectAnswer, Score FROM question WHERE SetID = ?";
                $stmt3 = $conn->prepare($questionQuery);
                $stmt3->bind_param("i", $setID);
                $stmt3->execute();
                $questionResult = $stmt3->get_result();

                while ($row = $questionResult->fetch_assoc()) {
                    $questions[] = $row; // Store the questions in the array
                }
            }
        }

        $conn->close();
    }
}

// Pagination logic
$questionsPerPage = 3;
$totalQuestions = count($questions); 
$totalPages = ceil($totalQuestions / $questionsPerPage);
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$currentPage = max(1, min($currentPage, $totalPages)); // Ensure current page is within bounds
$startIndex = ($currentPage - 1) * $questionsPerPage;
$questionsToDisplay = array_slice($questions, $startIndex, $questionsPerPage);

// Check if the form is submitted (when the "Next" button is clicked)
if (isset($_POST['next_page_button'])) {
    // Save answers for the current page to the session
    foreach ($_POST as $key => $value) {
        if (strpos($key, 'question-') === 0) {
            // Save the selected answer in the session
            $questionIndex = str_replace('question-', '', $key);
            $_SESSION['answers'][$questionIndex] = $value;


        }

    }
  

     $nextPage = isset($_POST['next_page']) ? (int)$_POST['next_page'] : 1;
    header("Location: ?page=" . ($currentPage + 1) . "&Stream=" . urlencode($selectedStream) . "&Subject=" . urlencode($selectedSubject));
    exit();

}

if (isset($_POST['previous_page_button'])) {
    // Save answers for the current page to the session
    foreach ($_POST as $key => $value) {
        if (strpos($key, 'question-') === 0) {
            // Save the selected answer in the session
            $questionIndex = str_replace('question-', '', $key);
            $_SESSION['answers'][$questionIndex] = $value;
          
            
        }

    }


    $previousPage = isset($_POST['previous_page']) ? (int)$_POST['previous_page'] : 1;
    header("Location: ?page=" . ($currentPage - 1) . "&Stream=" . urlencode($selectedStream) . "&Subject=" . urlencode($selectedSubject));
    exit();
}

// Store session variables when finish-attempt is clicked
if (isset($_POST["finish_attempt_button"])) {

    foreach ($_POST as $key => $value) {
        if (strpos($key, 'question-') === 0) {
            // Save the selected answer in the session
            $questionIndex = str_replace('question-', '', $key);
            $_SESSION['answers'][$questionIndex] = $value;
        }
    }

    if (isset($_POST['Stream']) && isset($_POST['Subject'])) {
        $_SESSION['Stream'] = $_POST['Stream'];
        $_SESSION['Subject'] = $_POST['Subject'];
    }
    if (isset($_POST['remaining_time'])) {
        $_SESSION['remaining_time'] = $remaining_time;
    }

    echo "<script> alert('Record successfully saved !');
     window.location.href='RevisionCornerResults.php';
    </script>";
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Revision Corner</title>
    <link rel="stylesheet" href="RevisionCorner.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100..700;1,100..700&family=League+Spartan:wght@100..900&family=Montserrat:ital,wght@0,100..900;1,100..900&family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

<section class="header">
    <nav>
    <a href="homepage.php"><img src="images/GTSPM.png" width="110" height="110"></a>
        <div class="nav-menu" id="navMenu">
            <i class="fa fa-times" onclick="hideMenu()"></i>
            <ul>
                <li><a href="homepage.php">HOME</a></li>
                <li><a href="RevisionCornerMainPage.php">Revision Corner</a></li>
                <li><a href="summary.php">Progress Report</a></li>
                <li><a href="homepage.php#targetDiv">About</a></li>
                <li><a href="ProfilePage.php"><img src="images/profile.png" width="40" height="40"></a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
    </nav> 
</section>

<section class="subject-select-box">
    <h1>Revision Corner</h1>
    <div class="select-menu1">
        <!-- Submit button to go back to view.php with selected values -->
        <form onsubmit="return validateForm() && confirmUpdate()" method="POST" action="view.php" id="revision-form">
            <input type="hidden" name="Stream" id="hidden-stream" value="<?php echo $selectedStream; ?>">
            <input type="hidden" name="Subject" id="hidden-subject" value="<?php echo $selectedSubject; ?>">
            <input type="submit" value="Update" id = "update-button" name="update">
        </form>
    </div>

    <!-- Form to show selected Stream and Subject options in RevisionCorner -->
    <div class="select-menu">
        <form onsubmit="return validateForm() && confirmUpdate()" method="GET" action="RevisionCorner.php">
        <label for="stream-select" style="font-weight: 900;">Stream:</label>
        <select name="Stream" id="stream-select">
            <option value="">--Select Stream--</option>
            
        </select>

            <label for="subject-select" style="font-weight: 900;">Subject:</label>
            <select name="Subject" id="subject-select">
                <option value="">--Select Subject--</option>
             
            </select>
        </form>
    </div>
</section>

<section class="quiz-questions">
    <h2 id = "text1" >All the Best ! </h2>
    <div class="timer">
        <h1>Timer: </h1>
        <p id="timer">
   


        </p>

    </div>

    <div class="question-box">
    <?php if (!empty($questionsToDisplay)): ?>
        <form method="POST"  id="question_submit" >
        
            <?php foreach ($questionsToDisplay as $index => $question): ?>
                <div class="question-box<?php echo ($index + 1); ?>">
                <h3 id = "quesnum">Question <?php echo ($startIndex + $index + 1); ?>:</h3>
                <p id = "questext"><?php echo htmlspecialchars($question['QuestionText']); ?></p>

                <!-- Add a hidden input for the default value -->
                <input type="hidden" name="question-<?php echo $startIndex + $index; ?>" value="null">

                    <ul>
                        <li>
                            <input type="radio" id = "ques" name="question-<?php echo $startIndex + $index; ?>" value="A" 
                                <?php echo (isset($_SESSION['answers'][$startIndex + $index]) && $_SESSION['answers'][$startIndex + $index] == 'A') ? 'checked' : ''; ?>> 
                            <?php echo htmlspecialchars($question['ChoiceA']); ?>
                        </li>
                        <li>
                            <input type="radio" id ="ques" name="question-<?php echo $startIndex + $index; ?>" value="B"
                                <?php echo (isset($_SESSION['answers'][$startIndex + $index]) && $_SESSION['answers'][$startIndex + $index] == 'B') ? 'checked' : ''; ?>> 
                            <?php echo htmlspecialchars($question['ChoiceB']); ?>
                        </li>
                        <li>
                            <input type="radio" id = "ques" name="question-<?php echo $startIndex + $index; ?>" value="C"
                                <?php echo (isset($_SESSION['answers'][$startIndex + $index]) && $_SESSION['answers'][$startIndex + $index] == 'C') ? 'checked' : ''; ?>> 
                            <?php echo htmlspecialchars($question['ChoiceC']); ?>
                        </li>
                        <li>
                            <input type="radio" id = "ques" name="question-<?php echo $startIndex + $index; ?>" value="D"
                                <?php echo (isset($_SESSION['answers'][$startIndex + $index]) && $_SESSION['answers'][$startIndex + $index] == 'D') ? 'checked' : ''; ?>> 
                            <?php echo htmlspecialchars($question['ChoiceD']); ?>
                        </li>
                    </ul>
                </div>
            <?php endforeach; ?>

            <!-- Hidden input to track the next page number -->
            <input type="hidden" name="next_page" value="<?php echo $currentPage + 1; ?>">
            <input type="hidden" name="previous_page" value="<?php echo $currentPage - 1; ?>">
            <input type="hidden" name="remaining_time" id="remaining_time" value="">
            

            <!-- Save and move to the next page -->
            <button type="submit" id  ="quizbut1" name="next_page_button" 
                <?php if ($currentPage >= $totalPages) echo 'disabled'; ?>> 
                Next
            </button>

            <button type="submit" id = "quizbut2" name="previous_page_button" 
                <?php if ($currentPage == 1) echo 'disabled'; ?>> 
                Previous
            </button>

            <button type="submit" id = "quizbut3" name="finish_attempt_button" value="finish_attempt_button" 
                <?php echo ($currentPage == $totalPages) ? '' : 'disabled'; ?>>
                Finish Attempt
            </button>
        </form>
        <script>
        document.addEventListener("DOMContentLoaded", function () {

        
        let timeValue = "<?php
            if (isset($_SESSION['remaining_time'])) {
                echo $_SESSION['remaining_time'];
        } else {
            echo $_SESSION['time'];
        }?>";
        console.log("Initial Time Value: " + timeValue);  // Debug: Check the value loaded from session

        if (timeValue !== "00:00:00" && timeValue !== "") {
            let [hours, minutes, seconds] = timeValue.split(":").map(Number);
            let timeLeft = hours * 3600 + minutes * 60 + seconds;

            function formatTime(seconds) {
                let hours = Math.floor(seconds / 3600);
                let minutes = Math.floor((seconds % 3600) / 60);
                let remainingSeconds = seconds % 60;
                return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
            }

            const timerInterval = setInterval(function () {
                timeLeft--;  // Decrease time left by 1 second
                console.log("Time left: " + timeLeft);  // Debug: Check remaining time

                const timerElement = document.getElementById("timer");
                if (timerElement) {
                    timerElement.textContent = formatTime(timeLeft);
                }

                // Update the remaining time in the hidden input
                document.getElementById('question_submit').addEventListener('submit', function(event) {
                const remainingTimeInput = document.getElementById("remaining_time");
                if (remainingTimeInput) {
                    remainingTimeInput.value = formatTime(timeLeft);
                    console.log("Updated Remaining Time Value: " + remainingTimeInput.value);  // Debug: Log the value
                    console.log('Hidden field value: ', document.getElementById("remaining_time").value);
                    
                }
            });

                // If time runs out, stop the timer and alert the user
                if (timeLeft <= 0) {
                    clearInterval(timerInterval);
                    alert("Time's up!");
                    header("Location: 'RevisionCornerResult.php'")
                }
            }, 1000);

    };
    });


</script>
        
    <?php else: ?>
        <p>No questions available for this subject.</p>
    <?php endif; ?>

    <!-- Pagination Links -->
    <div class="pagination">
        <!-- The Previous button will be disabled on the first page -->
        <?php if ($currentPage >= 1): ?>
            <!-- The form will redirect to the previous page after submission -->
        <?php endif; ?>

        <span>Page <?php echo $currentPage; ?> of <?php echo $totalPages; ?></span>

        <!-- The Next button will be disabled on the last page -->
        <?php if ($currentPage < $totalPages): ?>
            <!-- The form will redirect to the next page after submission -->
        <?php endif; ?>
    </div>
    </div>

</section>

<section class="footer">
        <h4>About Us</h4>
        <a href="homepage.php"><img src="images/GTSPM.png" width = "110" height="110"></a>
        <p>GTSPM is your ultimate learning companion for SPM success, offering interactive quizzes and comprehensive notes tailored to the SPM syllabus.<br> Designed to make studying engaging and effective, we empower students to excel in their exams with confidence.</p>
        <div class="icons">
            <i class="fa fa-facebook"></i>
            <i class="fa fa-twitter"></i>
            <i class="fa fa-instagram"></i>   
        </div>
        <p><i class="fa fa-copyright"></i>2024 GTSPM. All rights reserved</p>
</section>

<script>
    // Track selected values
    const selectedStream = "<?php echo $selectedStream; ?>";
    const selectedSubject = "<?php echo $selectedSubject; ?>";
    console.log("Selected Stream:", selectedStream);
    console.log("Selected Subject:", selectedSubject);

    // Populate stream and subject dropdowns dynamically
    fetch('FetchSubjectsDropDown.php')
        .then(response => response.json())
        .then(subjectdata => {
            const streamSelect = document.getElementById("stream-select");
            const subjectSelect = document.getElementById("subject-select");

            if (!subjectdata || Object.keys(subjectdata).length === 0) {
                alert("No streams or subjects found.");
                return;
            }

            // Populate Stream dropdown
            streamSelect.innerHTML = "<option value=''>--Select Stream--</option>";
            for (const stream in subjectdata) {
                const option = document.createElement("option");
                option.value = stream;
                option.textContent = stream.replace(/-/g, " ");
                if (stream === selectedStream) {
                    option.selected = true; // Preselect stream if it's the selected one
                }
                streamSelect.appendChild(option);
            }

            // Populate Subject dropdown based on selected Stream
            if (selectedStream !== "") {
                updateSubjects(selectedStream);
            }

            // Update Subject dropdown when Stream changes
            streamSelect.addEventListener("change", function () {
                const selectedStream = this.value;
                updateSubjects(selectedStream);
            });

            function updateSubjects(selectedStream) {
                subjectSelect.innerHTML = "<option value=''>--Select Subject--</option>";

                const availableSubjects = subjectdata[selectedStream] || [];

                availableSubjects.forEach(subject => {
                    const option = document.createElement("option");
                    option.value = subject.replace(/\s+/g, "-");
                    option.textContent = subject;
                    if (subject === selectedSubject.replace(/-/g, " ")) {
                        option.selected = true; // Preselect subject if it's the selected one
                    }
                    subjectSelect.appendChild(option);
                });
            }
        })
        .catch(error => {
            console.error("Error fetching data:", error);
            alert("Failed to load dropdown options. Please try again later.");
        });

</script>

<script>

        document.addEventListener("DOMContentLoaded", function () {
            const streamSelect = document.getElementById("stream-select");
            const subjectSelect = document.getElementById("subject-select");
            const hiddenStream = document.getElementById("hidden-stream");
            const hiddenSubject = document.getElementById("hidden-subject");

            function updateHiddenInputs() {
                hiddenStream.value = streamSelect.value;
                hiddenSubject.value = subjectSelect.value;
            }

            streamSelect.addEventListener("change", updateHiddenInputs);
            subjectSelect.addEventListener("change", updateHiddenInputs);
        });

        function validateAndConfirm() {
        // Validate the form
        if (!validateForm()) {
            return false; // Stop if validation fails
        }
        
        // Show confirmation prompt
        return confirmUpdate(); // Proceed only if the user confirms
    }

    function validateForm() {
        const stream = document.getElementById("stream-select").value;
        const subject = document.getElementById("subject-select").value;

        if (!stream || !subject) {
            alert("Please select both a Stream and a Subject.");
            return false; // Validation failed
        }
        return true; // Validation passed
    };

    function confirmUpdate() {
        return confirm("Are you sure you want to leave the quiz? \n\nAnswers will not be saved and you will have to restart!");
    };

    function confirmFinish(){
        return confirm("Are you sure you wish to submit ?")
    }

    </script>

    <script>
        var navMenu = document.getElementById("navMenu");
        function showMenu(){
            navMenu.style.right="0";
        }
        function hideMenu(){
            navMenu.style.right="-200px";
        }
    </script>

    

</body>
</html>
