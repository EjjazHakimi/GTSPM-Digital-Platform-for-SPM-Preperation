<?php
    if (isset($_GET['setID'])){
        include ("conn.php");
        $SetID = $_GET['setID'];
        $deleteQuestion = "DELETE FROM question WHERE SetID = '$SetID'";
        mysqli_query($conn, $deleteQuestion);
        $deleteQuizSet = "DELETE FROM quizset WHERE SetID = '$SetID'";
        mysqli_query($conn, $deleteQuizSet);
        if (!mysqli_error($conn)){
            echo "<script>alert('Quiz set and questions deleted successfully.');</script>";
            echo "<script>window.location.href = 'quiz-page.php';</script>";
        }else{
            echo "<script>alert('Error when delete');</script>";
        }
    }
?>