// script.js
document.addEventListener('DOMContentLoaded', () => {
    // Navigation Button Event Listeners
    const navButtons = document.querySelectorAll('.nav-btn');
    navButtons.forEach(button => {
        if (button.id !== 'forum') {
            button.addEventListener('click', () => {
                const destination = button.getAttribute('data-href');
                if (destination) {
                    window.location.href = destination;
                }
            });
        }
    });

});

// User Authentication (Basic Implementation)
class UserAuth {
    static login(username, password) {
        // Simulate login (replace with actual authentication)
        const validUsers = {
            'admin': 'password123',
            'teacher': 'teacher123'
        };

        if (validUsers[username] === password) {
            localStorage.setItem('loggedIn', 'true');
            localStorage.setItem('username', username);
            window.location.href = 'index.html';
            return true;
        }
        return false;
    }

    static logout() {
        localStorage.removeItem('loggedIn');
        localStorage.removeItem('username');
        window.location.href = 'login.html';
    }

    static isLoggedIn() {
        return localStorage.getItem('loggedIn') === 'true';
    }
}

// Quiz Management
class QuizManager {
    static createQuiz(quizData) {
        const quizzes = JSON.parse(localStorage.getItem('quizzes') || '[]');
        quizzes.push(quizData);
        localStorage.setItem('quizzes', JSON.stringify(quizzes));
    }

    static getAllQuizzes() {
        return JSON.parse(localStorage.getItem('quizzes') || '[]');
    }
}

// Learning Material Management
class MaterialManager {
    static uploadMaterial(materialData) {
        const materials = JSON.parse(localStorage.getItem('materials') || '[]');
        materials.push(materialData);
        localStorage.setItem('materials', JSON.stringify(materials));
    }

    static getAllMaterials() {
        return JSON.parse(localStorage.getItem('materials') || '[]');
    }
}