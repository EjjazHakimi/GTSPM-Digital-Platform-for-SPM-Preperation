<?php
// Step 1: Fetch subject data from the database
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "gtspm";

session_start();

// Database connection
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch subjects for the dropdown
$subject_query = "SELECT SubjectID, Name FROM subject";
$result = $conn->query($subject_query);

// Check for errors
if (!$result) {
    die("Error retrieving subjects: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="learningMaterials.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <title>LearningMaterials</title>
</head>
<body>
    <header>
        <nav id="nav-bar">
            <div id="div-left">
                <img src="Assests/Logo-GTSPM.png" alt="Logo">
            </div>
            <div id="div-right">
                <button id="learning-materials" type="button" class="nav-btn active"
                    onclick='window.location.href = "learningMaterials.php"'>Learning Materials</button>
                <button id="quiz" type="button" class="nav-btn"
                    onclick='window.location.href = "quiz-page.php"'>Quiz</button>
                <button id="dashboard" type="button" class="nav-btn"
                    onclick='window.location.href = "index.php"'>Dashboard</button>
                <button id="monitor-student" type="button" class="nav-btn"
                    onclick='window.location.href = "MonitorStudent.php"'>Monitor Student</button>
            </div>
        </nav>
    </header>
    <br>
    <div class = table>
    <h2 class="section-title">Available Materials</h2>

<?php

$query = "SELECT * FROM materials";
$result2 = $conn->query($query);

// Check if data exists

if ($result2->num_rows > 0) {
    // Start the table
    echo '<table border="1">';
    
    // Display the first row as the header (to be hidden in mobile)
    echo '<tr>';
    echo '<td data-label="MaterialsID">MaterialsID</td>';
    echo '<td data-label="EducatorID">EducatorID</td>';
    echo '<td data-label="SubjectID">SubjectID</td>';
    echo '<td data-label="Type">Type</td>';
    echo '<td data-label="Name">Name</td>';
    echo '<td data-label="FilePath">FilePath</td>';
    echo '<td data-label="Upload Date">Upload Date</td>';
    echo '<td data-label="Title">Title</td>';
    echo '<td data-label="Action">Action</td>';
    echo '</tr>';

    // Loop through the data and display it
    while ($row = $result2->fetch_assoc()) {
        echo '<tr>';
        echo '<td data-label="MaterialsID">' . $row['MaterialsID'] . '</td>';
        echo '<td data-label="EducatorID">' . $row['EducatorID'] . '</td>';
        echo '<td data-label="SubjectID">' . $row['SubjectID'] . '</td>';
        echo '<td data-label="Type">' . $row['Type'] . '</td>';
        echo '<td data-label="Name">' . $row['name'] . '</td>';
        echo '<td data-label="FilePath">' . $row['FilePath'] . '</td>';
        echo '<td data-label="Upload Date">' . $row['upload_date'] . '</td>';
        echo '<td data-label="Title">' . $row['Title'] . '</td>';
        echo '<td data-label="Action"><button class="btn btn-primary" onclick="confirmDelete(' . $row['MaterialsID'] . ')">Delete</button></td>';
        echo '</tr>';
    }

    // End the table
    echo '</table>';
} else {
    echo 'No materials found.';
}
?>

</div>
<div class="container">
    <h2 class="section-title">Upload Material</h2>
        <form action="upload.php" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="file" class="form-label">Select file</label>
                <input type="file" class="form-control" name="file" id="file" required>
            </div>
            
            <!-- Step 2: Dropdown menu for subjects -->
            <div class="mb-3">
                <label for="subjectID" class="form-label">Select Subject</label>
                <select class="form-select" name="SubjectID" id="subjectID" required>
                    <option value="">-- Select Subject --</option>
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <option value="<?php echo $row['SubjectID']; ?>">
                            <?php echo $row['Name']; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            <div class ="mb-3">
            <label for="title" class="form-label">Insert Title</label>
                <input type="text" class="form-control" name="title" id="title" required>
                </div>
            <button type="submit" class="btn btn-primary">Upload file</button>
            
        </form>
    </div>
    <footer class="footer">
        <p>&copy; 2024 Learning Management System. All rights reserved.</p>
    </footer>
</body>
</html>

<script>
    // JavaScript function to confirm deletion
    function confirmDelete(materialsID) {
        if (confirm("Are you sure you want to delete this file?")) {
            // Redirect to a PHP script to handle the deletion
            window.location.href = "deleteLearningMaterial.php?id=" + materialsID;
        }
    }
</script>