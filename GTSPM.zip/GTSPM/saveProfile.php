<?php
session_start();

$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "gtspm";

// Check for session
if (!isset($_SESSION['user_id'])) {
    die("Error: User not logged in.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    echo "<pre>";
    print_r($_POST);
    echo "</pre>";
}

$studentID = $_SESSION['user_id'];

// Check for POST data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $username = $_POST['username'] ?? '';
    $avatar = $_POST['avatar'] ?? 'A 1.png'; // Default avatar
    $avatarPath = 'images/' . $avatar; 
    


    // Database connection
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Update query
    $sql = "UPDATE student SET Name = ?, Email = ?, Username = ?, Avatar = ? WHERE StudentID = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("ssssi", $name, $email, $username, $avatar, $studentID);
        $stmt->execute();

        // Close statement and database connection
        $stmt->close();
        $conn->close();

        // Redirect to profile page after successful update
        header("Location: ProfilePage.php?success=1");
        exit();
    } else {
        die("Error: SQL preparation failed.");
    }
} else {
    die("Invalid request method.");
}
?>

