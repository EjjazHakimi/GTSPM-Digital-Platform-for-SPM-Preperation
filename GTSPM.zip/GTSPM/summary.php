<?php
session_start();

$conn = include("conn.php");

$userID = $_SESSION['user_id'];
$username = $_SESSION['user_name'];

if (!isset($_SESSION['user_id'])){
    echo  "<script> alert('Please login to continue !') 
    window.location.href='homepage.php'
    </script>";
}


$sql = "
    SELECT 
    s.Grade AS StudentGrade,
    sub.Name AS SubjectName,
    sub.Stream AS SubjectStream,
    COUNT(q.QuizID) AS TotalQuestions,
    sm.TotalScore AS TotalScore,
    ROUND((sm.TotalScore / COUNT(q.QuizID)) * 100, 2) AS Accuracy,
    Date
    FROM 
    summary sm
    JOIN 
    student s ON s.StudentID = sm.StudentID
    JOIN 
    quizset qs ON qs.SetID = sm.SetID
    JOIN 
    subject sub ON sub.SubjectID = qs.SubjectID
    JOIN 
    question q ON q.SetID = sm.SetID
    WHERE 
    s.Name = '$username'
    AND 
    sm.StudentID = '$userID'
    GROUP BY 
    sm.SummaryID;
";

$result = $conn->query($sql);

$quizzes = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $quizzes[] = $row;
    }
} else {
    echo "<p>No quiz data available!</p>";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="summary.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100..700;1,100..700&family=League+Spartan:wght@100..900&family=Montserrat:ital,wght@0,100..900;1,100..900&family=Open+Sans:ital,wght@0,300..800;1,300..800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Summary</title>
</head>
<body>
    <section class="header">
        <nav>
            <a href="homepage.html"><img src="images/GTSPM.png" width="110" height="110"></a>
            <div class="nav-menu" id="navMenu">
                <i class="fa fa-times" onclick="hideMenu()"></i>
                <ul>
                <ul>
                <li><a href="homepage.php">HOME</a></li>
                <li><a href="RevisionCornerMainPage.php">Revision Corner</a></li>
                <li><a href="summary.php">Progress Report</a></li>
                <li><a href="homepage.php#targetDiv">About</a></li>
                <li><a href="ProfilePage.php"><img src="images/profile.png" class="profile-img" width="40" height="40"></a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
                </ul>
            </div>
            <i class="fa fa-bars" onclick="showMenu()"></i>
        </nav>
    </section>

    <div class="summary-container">
        <?php
        if (!empty($quizzes)) {
            foreach ($quizzes as $quiz) {
                echo "
                <div class='quiz-card'>
                    <h3>Student: $username </h3>
                    <p>Grade: {$quiz['StudentGrade']}</p>
                    <h4>Subject: {$quiz['SubjectName']} ({$quiz['SubjectStream']})</h4>
                    <p>Total Questions: {$quiz['TotalQuestions']}</p>
                    <p>Correct Answers: {$quiz['TotalScore']}</p>
                    <p>Accuracy: {$quiz['Accuracy']}%</p>
                    <p>Date: {$quiz['Date']}</p>
                </div>";
            }
        } else {
            echo "<p>No quiz data to display.</p>";
        }
        ?>
    </div>

    <!--Footer-->
    <section class="footer">
        <h4>About Us</h4>
        <a href="homepage.html"><img src="images/GTSPM.png" width = "110" height="110"></a>
        <p>GTSPM is your ultimate learning companion for SPM success, offering interactive quizzes and comprehensive notes tailored to the SPM syllabus.<br> Designed to make studying engaging and effective, we empower students to excel in their exams with confidence.</p>
        <div class="icons">
            <i class="fa fa-facebook"></i>
            <i class="fa fa-twitter"></i>
            <i class="fa fa-instagram"></i>   
        </div>
        <p><i class="fa fa-copyright"></i>2024 GTSPM. All rights reserved</p>
    </section>

    <script>
        function showMenu() {
            document.getElementById("navMenu").style.right = "0";
        }

        function hideMenu() {
            document.getElementById("navMenu").style.right = "-200px";
        }
    </script>
</body>
</html>
