<?php
session_start();

unset($_SESSION['answers']);
unset($_SESSION['timer']);
unset($_SESSION['remaining_time']);

if (isset($_GET['deleted']) && $_GET['deleted'] == 'true') {
    echo '<script>alert("Your account has been deleted successfully.");</script>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GTSPM Homepage</title>
    <!--Swiper CSS-->
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<section class="header">
    <nav>
    <a href="homepage.php"><img src="images/GTSPM.png" width="110" height="110"></a>
        <div class="nav-menu" id="navMenu">
            <i class="fa fa-times" onclick="hideMenu()"></i>
            <ul>
                <li><a href="homepage.php">HOME</a></li>
                <li><a href="RevisionCornerMainPage.php">Revision Corner</a></li>
                <li><a href="summary.php">Progress Report</a></li>
                <li><a href="#targetDiv">About</a></li>
                <li><a href="ProfilePage.php"><img src="images/profile.png" class="profile-img"></a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
    </nav>

    <div class="text-box">
        <h1>GTSPM</h1>
        <p>GTSPM is dedicated to assist upper form students of SMK Puteri. <br> It strives to provide readily provide educational sources for students to optimze.</p>
        <a href="#targetDiv" class="info-btn">Let's learn more about GTSPM!</a>
    </div>
    </section>
    <!--About GTSPM-->
    <section class="Quiz" id = "targetDiv">
        <h1>What can GTSPM do for you?</h1>
        <div class="row">
            <div class="quiz-col">
                <img src="images/quiz.jpg">
                <h3>Create Quizzes</h3>
                <p>Design your own quizzes tailored to your learning needs.</p>
            </div>
            <div class="quiz-col">
                <img src="images/study.jpg">
                <h3>Obtain Study Materials</h3>
                <p>A variety of comprehensive notes and resources <br> would be accessible to make you excel in SPM</p>
            </div>
            <div class="quiz-col">
                <img src="images/test.jpg">
                <h3>Test Yourself</h3>
                <p>Take quizzes available in GTSPM to test your <br> knowledge as practice makes perfect.</p>
            </div>
        </div>
    </section>
    <script>
        var navMenu = document.getElementById("navMenu");
        function showMenu(){
            navMenu.style.right="0";
        }
        function hideMenu(){
            navMenu.style.right="-200px";
        }
    </script> <!--this javascript code is used to make the hamburger menu slide appear from the right when open and disappear from the screen when closed-->
    <!--Review Section-->
    <section class="Review">
        <h1>What teachers say about GTSPM</h1>
        <div class="row">
            <div class="Review-col">
                <img src="images/person1.jpg">
                <div>
                    <p>GTSPM is an incredible platform for SPM students! The quizzes are engaging, and the notes are well-structured, making it a valuable resource for exam preparation. My students have shown noticeable improvement</p>
                    <h3>Arthur</h3>
                    <h4>English Teacher</h4>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-o"></i>
                </div>
            </div>
            <div class="Review-col">
                <img src="images/person2.jpg">
                <div>
                    <p>As a teacher, I highly recommend GTSPM. It provides a comprehensive way for students to revise key concepts and test their knowledge effectively.The interactive approach keeps them motivated.</p>
                    <h3>James</h3>
                    <h4>History Teacher</h4>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star"></i>
                    <i class="fa fa-star-half-o"></i>
               </div>
            </div>
        </div>
    </section>
<!--Footer-->
    <section class="footer">
        <h4>About Us</h4>
        <a href="homepage.html"><img src="images/GTSPM.png" width = "110" height="110"></a>
        <p>GTSPM is your ultimate learning companion for SPM success, offering interactive quizzes and comprehensive notes tailored to the SPM syllabus.<br> Designed to make studying engaging and effective, we empower students to excel in their exams with confidence.</p>
        <div class="icons">
            <i class="fa fa-facebook"></i>
            <i class="fa fa-twitter"></i>
            <i class="fa fa-instagram"></i>   
        </div>
        <p><i class="fa fa-copyright"></i>2024 GTSPM. All rights reserved</p>
    </section>
</body>
</html>
