<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monitor Student</title>
    <link rel="stylesheet" href="MonitorStudent.css">
</head>

<body>
    <header>
        <nav id="nav-bar">
            <div class="nav-container">
                <div id="div-left">
                    <a href="index.php">
                        <img src="Assests/Logo-GTSPM.png" alt="GTSPM Logo" class="logo">
                    </a>
                </div>
                <div class="nav-right">
                    <ul class="nav-links">
                        <li>
                            <a href="learningMaterials.php"
                                class="nav-btn <?php echo (basename($_SERVER['PHP_SELF']) == 'learningMaterials.php') ? 'active' : ''; ?>">
                                Learning Materials
                            </a>
                        </li>
                        <li>
                            <a href="quiz-page.php"
                                class="nav-btn <?php echo (basename($_SERVER['PHP_SELF']) == 'quiz-page.php') ? 'active' : ''; ?>">
                                Quiz
                            </a>
                        </li>
                        <li>
                            <a href="index.php"
                                class="nav-btn <?php echo (basename($_SERVER['PHP_SELF']) == 'index.php') ? 'active' : ''; ?>">
                                Dashboard
                            </a>
                        </li>
                        <li>
                            <a href="MonitorStudent.php"
                                class="nav-btn <?php echo (basename($_SERVER['PHP_SELF']) == 'MonitorStudent.php') ? 'active' : ''; ?>">
                                Monitor Student
                            </a>
                        </li>
                    </ul>

                    <div class="profile">
                        <button class="profile-toggle" onclick="toggleProfileMenu(event)" aria-label="Profile Menu">
                            <img src="Assests/profile_icon.jpg" alt="Profile" class="profile-icon">
                        </button>
                        <div class="profile-dropdown">
                            <a href="#">My Profile</a>
                            <a href="#">Settings</a>
                            <a href="logout.php" class="logout">Logout</a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <div class="container">
        <div class="sidebar">
            <h2>Students</h2>
            <div class="search-bar">
                <input type="text" id="searchStudent" onkeydown="updateOption()" placeholder="Search Student">
            </div>
            <div class="scrollContainer">
                <ul id="studentList">
                    <!-- get stduent name -->
                    <?php
                    include("conn.php");
                    $sql = "SELECT StudentID, Name FROM student; ";
                    $result = mysqli_query($conn, $sql);
                    if (!$result) {
                        echo "Error: " . mysqli_error($conn);
                        return;
                    }
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo '<li data-value="' . $row['StudentID'] . '">' . $row['Name'] . '</li>';
                    }
                    ?>
                </ul>
            </div>
        </div>
        <div class="main-content">
            <div class="student-info">
                <h3>Student Details</h3>
                <div class="details">
                    <div>Name: John Doe</div>
                    <div>Grade: 10</div>
                    <div>School Year: 2024</div>
                    <div>Stream: Science</div>
                    <div>Recent Quizzes: 3</div>
                </div>

                <!-- Recent Quizzes Table -->
                <h3>Recent Quizzes</h3>
                <div class="recent-quizzes">
                    <table class="recent-details">
                        <thead>
                            <tr>
                                <th>Quiz</th>
                                <th>Date</th>
                                <th>Score</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Math Quiz 1</td>
                                <td>2024-12-01</td>
                                <td>95%</td>
                            </tr>
                            <tr>
                                <td>Science Quiz 2</td>
                                <td>2024-12-05</td>
                                <td>88%</td>
                            </tr>
                            <tr>
                                <td>History Quiz 3</td>
                                <td>2024-12-07</td>
                                <td>80%</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        <p>&copy; 2024 EduPlatform. All rights reserved.</p>
    </div>
    <!-- FontAwesome for icons -->
    <!-- <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script> -->

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Add click listener to the <ul> parent for event delegation
            document.getElementById("studentList").addEventListener("click", function (event) {
                if (event.target.tagName === "LI") { // Check if the clicked item is an <li>
                    const selectedName = event.target.textContent.trim();
                    const selectedID = event.target.getAttribute("data-value");
                    console.log("Selected Student:", selectedName);
                    console.log(selectedID);
                    displayInfo(selectedID);
                }
            });
        });


        function updateOption() {
            const filter = document.getElementById('searchStudent').value.toLowerCase(); // Get input value and convert to lowercase
            const students = document.querySelectorAll("#studentList li"); // Select all list items
            students.forEach((student) => {
                const text = student.textContent.toLowerCase(); // Get student name
                if (text.includes(filter)) {
                    student.style.display = ""; // Show matching students
                } else {
                    student.style.display = "none"; // Hide non-matching students
                }
            });
        };

        function displayInfo(studentID) {
            const xhr = new XMLHttpRequest();
            xhr.open("GET", "getStudentProgress.php?ID=" + studentID, true);
            xhr.onload = function () {
                if (xhr.status === 200) {
                    try {
                        const data = JSON.parse(xhr.responseText);

                        if (data.error) {
                            console.error(data.error);
                            alert(data.error);
                            return;
                        }

                        // Update student details
                        const detailsDiv = document.querySelector(".student-info .details");
                        detailsDiv.innerHTML = `
                <div>Name: ${data.studentDetails.Name}</div>
                <div>Grade: ${data.studentDetails.Grade}</div>
                <div>School Year: ${data.studentDetails.SchoolYear}</div>
                <div>Stream: ${data.studentDetails.Stream}</div>
            `;

                        // Update recent quizzes table
                        const quizTableBody = document.querySelector(".recent-details tbody");
                        quizTableBody.innerHTML = ""; // Clear old data
                        if (data.recentQuizzes.length > 0) {
                            data.recentQuizzes.forEach(quiz => {
                                const row = document.createElement("tr");
                                row.innerHTML = `
                        <td>${quiz.Quiz}</td>
                        <td>${quiz.Date}</td>
                        <td>${quiz.Score}%</td>
                    `;
                                quizTableBody.appendChild(row);
                            });
                        } else {
                            const row = document.createElement("tr");
                            row.innerHTML = `<td colspan="3">No recent quizzes available</td>`;
                            quizTableBody.appendChild(row);
                        }
                    } catch (e) {
                        console.error("Invalid JSON response:", xhr.responseText);
                    }
                } else {
                    console.error("Server error:", xhr.statusText);
                }
            };
            xhr.onerror = function () {
                console.error("Request failed");
            };
            xhr.send();
        }

        function toggleProfileMenu(event) {
    event.stopPropagation();
    const profileDropdown = document.querySelector('.profile-dropdown');
    const isActive = profileDropdown.classList.toggle('active');
    const toggleButton = document.querySelector('.profile-toggle');
    toggleButton.setAttribute('aria-expanded', isActive);

    document.addEventListener('click', function closeMenu(e) {
        if (!e.target.closest('.profile')) {
            profileDropdown.classList.remove('active');
            toggleButton.setAttribute('aria-expanded', false);
            document.removeEventListener('click', closeMenu);
        }
    });
};

    </script>



</body>

</html>