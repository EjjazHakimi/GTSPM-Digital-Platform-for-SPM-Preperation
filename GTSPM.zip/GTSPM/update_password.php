<?php
session_start();

$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "gtspm";

if (!isset($_SESSION['user_id'])) {
    die("Error: StudentID not set in session. Please log in again.");
}

$studentID = $_SESSION['user_id'];
$currentPassword = $_POST['currentPassword'];
$newPassword = $_POST['newPassword'];
$retypePassword = $_POST['retypePassword'];

// Connect to database
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch the current password from the database
$sql = "SELECT Password FROM student WHERE StudentID = ?";
$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param("s", $studentID);
    $stmt->execute();
    $stmt->bind_result($storedPassword);

    if ($stmt->fetch()) {
        // Check if the current password entered matches the stored password
        if (!password_verify($currentPassword, $storedPassword)) {
            // Current password is wrong
            echo "<script>alert('The current password is wrong.'); window.location.href = 'ProfilePage.php';</script>";
            exit;
        }

        // Check if the new password is the same as the current password
        if ($currentPassword == $newPassword) {
            // New password is the same as the current password
            echo "<script>alert('The new password cannot be the same as the current password.'); window.location.href = 'ProfilePage.php';</script>";
            exit;
        }

        // Check if the new password and retype password match
        if ($newPassword !== $retypePassword) {
            // Passwords do not match
            echo "<script>alert('The retyped password does not match the new password.'); window.location.href = 'ProfilePage.php';</script>";
            exit;
        }

        // Clear the statement result to avoid command sync issues
        $stmt->close();

        // Update the password in the database
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $updateSql = "UPDATE student SET Password = ? WHERE StudentID = ?";
        $updateStmt = $conn->prepare($updateSql);
        if ($updateStmt) {
            $updateStmt->bind_param("ss", $hashedPassword, $studentID);
            if ($updateStmt->execute()) {
                // Successfully updated password
                echo "<script>alert('Password updated successfully!'); window.location.href = 'ProfilePage.php';</script>";
            } else {
                echo "<script>alert('Error: Failed to update password.'); window.location.href = 'ProfilePage.php';</script>";
            }
            $updateStmt->close();
        } else {
            echo "<script>alert('Error: SQL preparation failed for updating password.'); window.location.href = 'ProfilePage.php';</script>";
        }
    } else {
        echo "<script>alert('Error: User not found.'); window.location.href = 'ProfilePage.php';</script>";
    }

    $stmt->close();
} else {
    echo "<script>alert('Error: SQL preparation failed.'); window.location.href = 'ProfilePage.php';</script>";
}

$conn->close();
?>
