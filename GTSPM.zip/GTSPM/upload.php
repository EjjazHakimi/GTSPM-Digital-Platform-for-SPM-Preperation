<?php
// Database connection
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "gtspm";
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

session_start();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle the file upload and database insertion
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Define target directory relative to project folder
    $target_dir = "fileupload/"; // Relative path for saving in the database
    $absolute_dir = __DIR__ . "/" . $target_dir; // Absolute path for file storage

    // Ensure the directory exists
    if (!is_dir($absolute_dir)) {
        if (!mkdir($absolute_dir, 0777, true)) {
            die("Error: Unable to create the uploads directory.");
        }
    }

    // Check for file upload
    if (isset($_FILES["file"])) {
        if ($_FILES["file"]["error"] == 0) {
            $filename = basename($_FILES["file"]["name"]);
            $file_type = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            $file_title = $_POST['title'];

            // Allowed file types
            $allowed_types = array("jpg", "jpeg", "png", "gif", "pdf");
            if (!in_array($file_type, $allowed_types)) {
                echo "Sorry, only JPG, JPEG, PNG, GIF, and PDF files are allowed.";
            } else {
                // Use hardcoded test values for EducatorID and SubjectID
                $educatorID = $_SESSION['EducatorID']; // Hardcoded EducatorID
                $subjectID =  $_POST['SubjectID'];  // Hardcoded SubjectID

                // Define paths
                $relative_path = $target_dir . $filename; // File path to store in the database
                $absolute_path = $absolute_dir . $filename; // Full file path to move the file

                // Move the uploaded file to the specified directory
                if (move_uploaded_file($_FILES["file"]["tmp_name"], $absolute_path)) {
                    $filesize = $_FILES["file"]["size"];
                    $filetype = $_FILES["file"]["type"];

                    // Insert file data into database
                    $sql = "INSERT INTO materials (name, upload_date, Type, SubjectID, EducatorID, FilePath, Title)
                            VALUES (?, NOW(), ?, ?, ?, ?, ?)";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("ssssss", $filename, $filetype, $subjectID, $educatorID, $relative_path, $file_title);

                    if ($stmt->execute()) {
                        echo "<script type='text/javascript'> alert('The file " . htmlspecialchars($filename) . " has been uploaded successfully.'); 
                        window.location.href = 'learningMaterials.php'; 
                        </script>";
                    } else {
                        echo "Database error: " . $stmt->error;
                    }
                } else {
                    echo "Error: Unable to move the uploaded file.";
                }
            }
        } else {
            echo "File upload error code: " . $_FILES["file"]["error"];
        }
    } else {
        echo "<script type='text/javascript'> alert('Error in uploading file' has been uploaded successfully.'); 
                        window.location.href = 'learningMaterials.php'; 
                        </script>";
    }
}

$conn->close();
?>

