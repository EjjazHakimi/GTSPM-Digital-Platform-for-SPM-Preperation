<?php

function getSubject($stream){
    include("conn.php");

    // Sanitize the stream to prevent SQL injection
    $stream = mysqli_real_escape_string($conn, $stream);

    // Proper SQL query with quotes around the stream value
    $sql = "SELECT SubjectID, Name FROM subject WHERE Stream = '$stream'";

    // Execute the query and handle errors
    $result = mysqli_query($conn, $sql);
    if (!$result) {
        echo "Error: " . mysqli_error($conn);
        return;
    }

    // Initialize the $options variable to store the generated HTML
    $options = "";
    while ($row = mysqli_fetch_assoc($result)) {
        $subjectID = $row['SubjectID'];
        $options .= "<option value='".$subjectID."'>" . htmlspecialchars($row['Name']) . "</option>";
    }

    // Output the options
    echo $options;
}

if (isset($_GET['stream'])) {
    $stream = $_GET['stream']; // Get the stream value passed via AJAX
    getSubject($stream); // Call the function with the selected stream
}
?>
