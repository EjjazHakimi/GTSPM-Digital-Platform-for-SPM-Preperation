<?php
session_start();

ini_set('display_errors', 1);
error_reporting(E_ALL);

$conn = new mysqli('localhost', 'root', '', 'gtspm');
if ($conn->connect_error) {
    die('Connection Failed: ' . $conn->connect_error);
}

$timeout_duration = 1800;
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=true");
    exit();
}
$_SESSION['LAST_ACTIVITY'] = time();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['formtype'])) {
        $formtype = $_POST['formtype'];

    if ($formtype == 'signupform') {
    $Username = trim($_POST['Username']);
    $Email = trim($_POST['Email']);
    $Password = $_POST['Password'];
    $ConfirmPassword = $_POST['ConfirmPassword'];
    $Name = trim($_POST['Name']);
    $Stream = $_POST['Stream'];
    $Grade = $_POST['Grade'];
    $SchoolYear = $_POST['SchoolYear'];

    if (empty($Username)) {
        echo "Username is required.";
        exit;
    }

    if ($Password !== $ConfirmPassword) {
        echo "Passwords do not match.";
        exit;
    }

    $prefix = "ST";
    $uniquenumber = rand(0, 9999);  // Generate a random number between 1000 and 9999
    $id = $prefix . $uniquenumber;


    $checkQuery = "SELECT COUNT(*) FROM student WHERE Username = ?";
    $stmt_check = $conn->prepare($checkQuery);
    $stmt_check->bind_param("s", $Username);
    $stmt_check->execute();
    $stmt_check->bind_result($count);
    $stmt_check->fetch();
    $stmt_check->close();

    if ($count > 0) {
        die("Username already exists.");
    }

    $query = "INSERT INTO student (StudentID, Username, Password, Email, Name, Stream, Grade, SchoolYear) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt_insert = $conn->prepare($query);
    $stmt_insert->bind_param("ssssssis", $id, $Username, $Password, $Email, $Name, $Stream, $Grade, $SchoolYear);

    if (!$stmt_insert->execute()) {
        die(json_encode(["error" => "SQL error: " . $stmt_insert->error]));
    }

    $stmt_insert->close();
    $conn->close();

    header("Location: login.php");
    exit();
}


   if ($formtype == 'edusignupform') {

    $Username = trim($_POST['eduUsername']);
    $Email = trim($_POST['eduEmail']);
    $Password = $_POST['eduPassword'];
    $ConfirmPassword = $_POST['eduConfirmPassword'];
    $Name = trim($_POST['eduName']);
    if (isset($_POST['edugender'])) {
        $Gender = $_POST['edugender'];
    }
    $PhoneNum = $_POST['eduPhoneNumber'];

    if (empty($Username)) {
        echo "Username is required.";
        exit;
    }

    if ($Password !== $ConfirmPassword) {
        echo "Passwords do not match.";
        exit;
    }

    $prefix = "ED";
    $uniquenumber = rand(0, 9999);  // Generate a random number between 1000 and 9999
    $id = $prefix . $uniquenumber;

    $checkQuery = "SELECT COUNT(*) FROM educator WHERE Username = ?";
    $stmt_check = $conn->prepare($checkQuery);
    $stmt_check->bind_param("s", $Username);
    $stmt_check->execute();
    $stmt_check->bind_result($count);
    $stmt_check->fetch();
    $stmt_check->close();

    if ($count > 0) {
        die("Username already exists.");
    }

    $query = "INSERT INTO educator (EducatorID, Username, Password, Email, Name, Phone, Gender) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt_insert = $conn->prepare($query);
    $stmt_insert->bind_param("sssssss", $id, $Username, $Password, $Email, $Name, $PhoneNum, $Gender);

    if (!$stmt_insert->execute()) {
        die(json_encode(["error" => "SQL error: " . $stmt_insert->error]));
    }

    $stmt_insert->close();
    $conn->close();

    header("Location: login.php");
    exit();
}
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script src="signup.js" defer></script>
    <link rel="stylesheet" href="style1.css">
</head>
<body>

<div class ="wrapper">
Role:
<div class ="roleSelect" name = "roleSelect">
                <input type="radio" id ="student" name ="role" value ="Student" onclick = toggleForm()>
                <label for="student">Student</label>
                <input type="radio" id ="educator" name ="role" value ="Educator" onclick = toggleForm()>
                <label for="educator">Educator</label>
    </div>


    <div class="wrapper1"  id="signupWrapper" style="display: none;">
        <form id="signupform" name = 'signupform' action="signup.php" method="POST">
        <input type="hidden" name="formtype" value="signupform">
            <h1>Sign Up</h1>

            <div class="input-box">
                <input type="text" id="username" placeholder="Username" name="Username" required>
                <i class='bx bxs-user'></i>
            </div>

            <div class="input-box">
                <input type="email" id="email" placeholder="Email" name="Email" required>
                <i class='bx bxs-envelope'></i>
            </div>

            <div class="input-box">
                <input type="password" id="password" placeholder="Password" name="Password" required>
                <i class='bx bxs-lock-alt'></i>
            </div>

            <div class="input-box">
                <input type="password" id="confirmPassword" placeholder="Confirm Password" name="ConfirmPassword" required>
                <i class='bx bxs-lock-alt'></i>
            </div>

            <div class="input-box">
                <input type="text" id="name" placeholder="Enter Name" name="Name" required>
                <i class='bx bxs-lock-alt'></i>
            </div>

          

            <div class="input-box">
                <label for="Stream">Subject Stream:</label>
                <select id="stream-select" name="Stream" required>
                <option value=''>--Select Stream--</option>
                    <!-- Dynamically populate stream here -->
                </select>
            </div>

            <div class="input-box">
                <label for="Grade">Grade:</label>
                <select id="grade" name="Grade" required>
                    <option value="">Select Grade</option>
                    <option value="1">Form 1</option>
                    <option value="2">Form 2</option>
                    <option value="3">Form 3</option>
                    <option value="4">Form 4</option>
                    <option value="5">Form 5</option>
                </select>
            </div>

            <div class="input-box">
                <label for="SchoolYear">School Year:</label>
                <select id="schoolyear" name="SchoolYear" required>
                    <option value="">Select Year</option>
                    <option value="2020">2020</option>
                    <option value="2021">2021</option>
                    <option value="2022">2022</option>
                    <option value="2023">2023</option>
                    <option value="2024">2024</option>
                    <option value="2025">2025</option>
                </select>
            </div>

            <div class="terms-checkbox">
                <label><input type="checkbox" id="agreeTerms" name="termsCheckbox" required>I agree to the Terms & Conditions</label>
            </div>

            <button type="submit" class="btn">Sign Up</button>

            <div class="register-link">
                <p>Already have an account? <a href="login.php">Login</a></p>
            </div>
        </form>
    </div>
    
    <div class="wrapper2"  id="edusignupWrapper" style="display: none;">
        <form id="edusignupform" name = 'edusignupform' action="signup.php" method="POST">
        <input type="hidden" name="formtype" value="edusignupform">
            <h1>Sign Up</h1>

            <div class="input-box">
                <input type="text" id="eduusername" placeholder="Username" name="eduUsername" required>
                <i class='bx bxs-user'></i>
            </div>

            <div class="input-box">
                <input type="email" id="eduemail" placeholder="Email" name="eduEmail" required>
                <i class='bx bxs-envelope'></i>
            </div>

            <div class="input-box">
                <input type="password" id="edupassword" placeholder="Password" name="eduPassword" required>
                <i class='bx bxs-lock-alt'></i>
            </div>

            <div class="input-box">
                <input type="password" id="educonfirmPassword" placeholder="Confirm Password" name="eduConfirmPassword" required>
                <i class='bx bxs-lock-alt'></i>
            </div>

            <div class="input-box">
                <input type="text" id="eduname" placeholder="Enter Name" name="eduName" required>
                <i class='bx bxs-lock-alt'></i>
            </div>

            Gender
            <div class = "radio-gender" id = 'gender'>
                <input type="radio" id="edumale" name = "edugender" value = "Male">
                <label for = "male"> Male </label>
                <input type="radio" id="edufemale" name = "edugender" value = "Female">
                <label for = "female"> Female </label>
            </div>

            <div class="input-box">
                <input type="text" id="eduphone" placeholder="Enter PhoneNumber" name="eduPhoneNumber" required>
                <i class='bx bxs-lock-alt'></i>
            </div>

            <div class="terms-checkbox">
                <label><input type="checkbox" id="eduagreeTerms" name="termsCheckbox" required>I agree to the Terms & Conditions</label>
            </div>

            <button type="submit" class="btn">Sign Up</button>

            <div class="register-link">
                <p>Already have an account? <a href="login.php">Login</a></p>
            </div>
</form>
</div>
</div>
        

    <script>
        function validatePassword() {
            var password = document.getElementById("password").value;
            var confirmPassword = document.getElementById("confirmPassword").value;

            if (password !== confirmPassword) {
                alert("Passwords do not match. Please try again.");
                return false;
            }
            return true;
        }
    </script>

    <script>
        // Fetch and populate dropdowns for Stream and Subject dynamically
    fetch('FetchSubjectsDropDown.php')
        .then(response => response.json())
        .then(subjectdata => {
            const streamSelect = document.getElementById("stream-select");

            if (!subjectdata || Object.keys(subjectdata).length === 0) {
                alert("No streams or subjects found.");
                return;
            }

            // Populate Stream dropdown
            streamSelect.innerHTML = "<option value=''>--Select Stream--</option>";
            for (const stream in subjectdata) {
                const option = document.createElement("option");
                option.value = stream;
                option.textContent = stream.replace(/-/g, " ");
                streamSelect.appendChild(option);
            }
        });

</script>

<script>
        function toggleForm() {
        // Get the radio button values and the wrapper
        var studentRadio = document.getElementById('student');
        var educatorRadio = document.getElementById('educator');
        var signupWrapper = document.getElementById('signupWrapper');
        var edusignupWrapper = document.getElementById('edusignupWrapper');
        
        // Show the form if "Student" is selected, otherwise hide it
        if (studentRadio.checked) {
            signupWrapper.style.display = 'block';
        } else {
            signupWrapper.style.display = 'none';
        } if (educatorRadio.checked) {
            edusignupWrapper.style.display = 'block';
        } else {
            edusignupWrapper.style.display = 'none';
        }

    }

    
</script>

</body>
</html>
