<?php
session_start();
$conn = include("conn.php"); 

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user_email = $_POST['email'] ?? '';
    $user_password = $_POST['password'] ?? '';

    $error_message = '';

    // Flags for user roles
    $EDuser_found = false;
    $STuser_found = false;

    // Check for Educator
    $educator_query = "SELECT EducatorID AS ID, Name, Email, Password FROM educator WHERE Email = ?";
    $stmt_educator = $conn->prepare($educator_query);
    $stmt_educator->bind_param("s", $user_email);
    $stmt_educator->execute();
    $educator_result = $stmt_educator->get_result();

    // Check for Student
    $student_query = "SELECT StudentID AS ID, Name, Email, Password FROM student WHERE Email = ?";
    $stmt_student = $conn->prepare($student_query);
    $stmt_student->bind_param("s", $user_email);
    $stmt_student->execute();
    $student_result = $stmt_student->get_result();

    // If Educator Found
    if ($educator_result->num_rows > 0) {
        $user = $educator_result->fetch_assoc();
        $EDuser_found = true;

    } 
    // If Student Found
    elseif ($student_result->num_rows > 0) {
        $user = $student_result->fetch_assoc();
        $STuser_found = true;

    }

    // Validate Password and Set Sessions
    if ($EDuser_found || $STuser_found) {
        if ($user_password === $user['Password']) {
            session_regenerate_id(true);

            if ($EDuser_found) {
                // Set Educator Session Variables
                $_SESSION['EducatorID'] = $user['ID'];
                $_SESSION['EducatorName'] = $user['Name'];
                $_SESSION['EducatorEmail'] = $user['Email'];
                $_SESSION['user_role'] = 'Educator';

                // Redirect to Educator Homepage
                header("Location: index.php");
                exit();
            }

            if ($STuser_found) {
                // Set Student Session Variables
                $_SESSION['user_id'] = $user['ID'];
                $_SESSION['user_name'] = $user['Name'];
                $_SESSION['user_email'] = $user['Email'];
                $_SESSION['user_role'] = 'Student';

                // Redirect to Student Homepage
                header("Location: homepage.php");
                exit();
            }
        } else {
            $error_message = 'Invalid password. Please try again.';
        }
    } else {
        $error_message = 'No user found with this email. Please check your credentials.';
    }

    // Close Statements
    $stmt_educator->close();
    $stmt_student->close();
    $conn->close();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style1.css">
</head>
<body>

    <div class="wrapper">
        <form action="login.php" method="POST">
            <h1>Login</h1>

            <div class="input-box">
                <input type="email" placeholder="Email" name="email" id="email" required>
                <i class='bx bxs-envelope'></i>
            </div>

            <div class="input-box">
                <input type="password" placeholder="Password" name="password" id="password" required>
                <i class='bx bxs-lock-alt'></i>
            </div>

            <button type="submit" class="btn">Login</button>

            <div class="register-link">
                <p>Don't have an account? <a href="signup.php">Sign Up</a></p>
            </div>

            <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                if (!$EDuser_found && !$STuser_found) {
                    echo "<p style='color: red;'>No user found with this email. Please check your credentials.</p>";
                } elseif (!($user_password === $user['Password'])) {
                    echo "<p style='color: red;'>Invalid password. Please try again.</p>";
                }
            }
            ?>
        </form>
    </div>
</body>
</html>
