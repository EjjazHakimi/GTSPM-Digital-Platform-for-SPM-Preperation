<?php
session_start();

$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "gtspm";

if (!isset($_SESSION['user_id'])) {
    echo  "<script> alert('Please login to continue !') 
    window.location.href='homepage.php'
    </script>";
}

$studentID = $_SESSION['user_id'];

// Connect to database
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user data
$sql = "SELECT Name, Email, Username, Avatar FROM student WHERE StudentID = ?";
$stmt = $conn->prepare($sql);

if ($stmt) {
    $stmt->bind_param("s", $studentID);
    $stmt->execute();
    $stmt->bind_result($name, $email, $username, $avatar);

    if (!$stmt->fetch()) {
        die("Error: Student data not found.");
    }

    $stmt->close();
} else {
    die("Error: SQL preparation failed.");
}

$conn->close();

// Ensure avatar is set to a default if not selected
$avatarPath = "images/" . ($avatar ? $avatar : 'A 1.png');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Management</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    
<?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
    <div class="success-message" style="background: #d4edda; color: #155724; padding: 10px; margin: 10px 0; border: 1px solid #c3e6cb;">
        Profile updated successfully!
    </div>
<?php endif; ?>

<!-- Navigation Section -->
<section class="header">
    <nav>
        <a href="homepage.php"><img src="images/GTSPM.png" width="110" height="110" alt="GTSPM Logo"></a>
        <div class="nav-menu" id="navMenu">
            <i class="fa fa-times" onclick="hideMenu()"></i>
            <ul>
                <li><a href="homepage.php">HOME</a></li>
                <li><a href="RevisionCornerMainPage.php">Revision Corner</a></li>
                <li><a href="summary.php">Progress Report</a></li>
                <li><a href="homepage.php#targetDiv">About</a></li>
                <li><a href="ProfilePage.php"><img src="images/profile.png" class="profile-img" alt="Profile"></a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
    </nav>
</section>

<!-- Profile Section -->
<section class="profile-page">
    <div class="sidebar">
        <ul>
            <li><a href="#" onclick="showSection('viewProfile'); activateLink(this);" class="active">Profile</a></li>
            <li><a href="#" onclick="showSection('changePassword'); activateLink(this);">Password</a></li>
            <li><a href="#" onclick="showSection('deleteAccount'); activateLink(this);">Delete Account</a></li>
        </ul>
    </div>
    
    <div class="profile-content">
    <div class="profile-content">

    <!-- View Profile Section -->
    <div id="viewProfile" class="profile-section">
        <h2>Profile</h2>
        <div class="profile-info">
            <!-- Avatar Image -->
            <img id="profileAvatar" src="<?php echo htmlspecialchars($avatarPath);?>" alt="Avatar" class="avatar">
            <p><strong>Name:</strong> <?php echo htmlspecialchars($name); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
            <p><strong>Username:</strong> <?php echo htmlspecialchars($username); ?></p>
            <button onclick="showSection('editProfile')" class="edit-btn">Edit Profile</button>
        </div>
    </div>

    <!-- Edit Profile Section -->
    <div id="editProfile" class="profile-section" style="display: none;">
        <h2>Edit Profile</h2>
        <div class="profile-flex-container">
            <div class="avatar-section">
                <!-- Avatar Image in Edit Mode -->
                <img id="editProfileAvatar" src="<?php echo htmlspecialchars($avatarPath); ?>" alt="Avatar" class="avatar">
                <button class="edit-avatar-btn" onclick="showAvatarPopup()">Edit Avatar</button>
            </div>
            <form id="profileForm" method="POST" action = "saveProfile.php">
                <input type="hidden" id="avatarInput" name="avatar" value="">

                <label for="name">Name:</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>">

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>">

                <label for="username">Username:</label>
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>">

                <button type="submit" class="save-changes-btn">Save Changes</button>
            </form>
        </div>
    </div>

    <!-- Avatar Popup -->
    <div id="avatarPopup" class="avatar-popup" style="display: none;">
        <h3>Pick an Avatar</h3>
        <div class="avatar-options">
            <!-- Avatar Selection Images -->
            <img src="images/A 1.png" alt="Avatar 1" onclick="selectAvatar('A 1.png')">
            <img src="images/A 2.png" alt="Avatar 2" onclick="selectAvatar('A 2.png')">
            <img src="images/A 3.png" alt="Avatar 3" onclick="selectAvatar('A 3.png')">
            <img src="images/A 4.png" alt="Avatar 4" onclick="selectAvatar('A 4.png')">
            <img src="images/A 5.png" alt="Avatar 5" onclick="selectAvatar('A 5.png')">
            <img src="images/A 6.png" alt="Avatar 6" onclick="selectAvatar('A 6.png')">
        </div>
        <button onclick="closeAvatarPopup()" class="popup-close-btn">Close</button>
    </div>

        <!-- Change Password Section -->
        <div id="changePassword" class="profile-section" style="display: none;">
            <h2>Change Password</h2>
            <form id="changePasswordForm" action="update_password.php" method="POST">
                <label for="currentPassword">Current Password:</label><br>
                <input type="password" id="currentPassword" name="currentPassword" required><br><br>

                <label for="newPassword">New Password:</label><br>
                <input type="password" id="newPassword" name="newPassword" required><br><br>

                <label for="retypePassword">Retype New Password:</label><br>
                <input type="password" id="retypePassword" name="retypePassword" required><br><br>

                <button type="submit" class="update-btn">Update</button>
            </form>
        </div>

        <!-- Delete Account Section -->
        <!-- Delete Account Section -->
        <div id="deleteAccount" class="profile-section" style="display: none;">
            <h2>Delete Account</h2>
            <p>Are you sure you want to delete your account?</p>
            <p>All your data will be permanently deleted.</p><br>
            <form action="deleteAccount.php" method="POST">
                <div class="button-container">
                    <button type="submit" class="delete-account-btn">Delete Account</button>
                    <button type="button" class="cancel-btn" onclick="showSection('viewProfile')">Cancel</button>
                </div>
            </form>
        </div>
        </div>
    </div>
</section>

<section class="footer">
        <h4>About Us</h4>
        <a href="homepage.html"><img src="images/GTSPM.png" width = "110" height="110"></a>
        <p>GTSPM is your ultimate learning companion for SPM success, offering interactive quizzes and comprehensive notes tailored to the SPM syllabus.<br> Designed to make studying engaging and effective, we empower students to excel in their exams with confidence.</p>
        <div class="icons">
            <i class="fa fa-facebook"></i>
            <i class="fa fa-twitter"></i>
            <i class="fa fa-instagram"></i>   
        </div>
        <p><i class="fa fa-copyright"></i>2024 GTSPM. All rights reserved</p>
    </section>


<script>
    function showSection(sectionId) {
        document.querySelectorAll('.profile-section').forEach(section => {
            section.style.display = 'none';
        });
        document.getElementById(sectionId).style.display = 'block';
    }

    function activateLink(clickedLink) {
        document.querySelectorAll('.sidebar ul li a').forEach(link => {
            link.classList.remove('active');
        });
        clickedLink.classList.add('active');
    }

    function showAvatarPopup() {
        document.getElementById('avatarPopup').style.display = 'block';
    }

    function closeAvatarPopup() {
        document.getElementById('avatarPopup').style.display = 'none';
    }

    // Select an Avatar and Update Profile Image
    function selectAvatar(avatarFileName) {
        const avatarPath = `images/${avatarFileName}`;
        document.getElementById('profileAvatar').src = avatarPath;  // Update profile image in View Mode
        document.getElementById('editProfileAvatar').src = avatarPath;  // Update profile image in Edit Mode
        document.getElementById('avatarInput').value = avatarFileName; // Update hidden input value
        console.log("Avatar Path Is:" + avatarPath);
        console.log ("Avatar filename = " + avatarFileName); 
        const avatarValue = document.getElementById('avatarInput').value;
        console.log("Avatar Input Value Before Submission:", avatarValue);
        closeAvatarPopup();  // Close the Avatar Popup
    }

    document.getElementById("changePasswordForm").addEventListener("submit", function(event) {
    // Get form data
    var currentPassword = document.getElementById("currentPassword").value;
    var newPassword = document.getElementById("newPassword").value;
    var retypePassword = document.getElementById("retypePassword").value;

    // Basic frontend validation
    if (newPassword === currentPassword) {
        alert("The new password cannot be the same as the current password.");
        event.preventDefault();
        return false;
    }

    if (newPassword !== retypePassword) {
        alert("The retyped password does not match the new password.");
        event.preventDefault();
        return false;
    }
});
</script>

<script>
        function showMenu() {
            document.getElementById("navMenu").style.right = "0";
        }

        function hideMenu() {
            document.getElementById("navMenu").style.right = "-200px";
        }
    </script>
</body>
</html>
