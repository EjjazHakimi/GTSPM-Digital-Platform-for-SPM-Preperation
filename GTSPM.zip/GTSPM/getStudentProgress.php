<?php
include("conn.php");

// Ensure valid StudentID is passed
if (!isset($_GET['ID'])) {
    header("Content-Type: application/json");
    echo json_encode(["error" => "Invalid StudentID"]);
    exit;
}

$studentID = $_GET['ID'];



// Fetch student details
$studentQuery = "SELECT Name, Stream, Grade, SchoolYear FROM student WHERE StudentID = ?";
$stmt = $conn->prepare($studentQuery);
$stmt->bind_param("s", $studentID);
$stmt->execute();
$studentResult = $stmt->get_result()->fetch_assoc();

// Check if student exists
if (!$studentResult) {
    header("Content-Type: application/json");
    echo json_encode(["error" => "No student found with ID: $studentID"]);
    exit;
}

// Fetch recent quizzes
$quizQuery = "SELECT SetID AS Quiz, TotalScore AS Score, Date FROM summary WHERE StudentID = ? ORDER BY Date DESC LIMIT 3";
$stmt = $conn->prepare($quizQuery);
$stmt->bind_param("s", $studentID);
$stmt->execute();
$quizResult = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Prepare response
$response = [
    "studentDetails" => $studentResult,
    "recentQuizzes" => $quizResult ?: [] // If no quizzes, return an empty array
];

// Return JSON response
header("Content-Type: application/json");
echo json_encode($response);
?>
