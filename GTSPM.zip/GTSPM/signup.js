document.getElementById('signupform').addEventListener('submit', function(event) {
    event.preventDefault();  // Prevents the default form submission

    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const agreeTerms = document.getElementById('agreeTerms').checked;


    if (!username || !email || !password || !confirmPassword) {
        alert("Please fill out all fields.");
        return;
    }

    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return;
    }

    if (!agreeTerms) {
        alert("You must agree to the terms and conditions.");
        return;
    }

    alert("Signup successful! Data will be saved.");

    // Ensure form submission happens after validation
    document.getElementById('signupform').submit(); 
});


document.getElementById('edusignupform').addEventListener('submit', function(event) {
    event.preventDefault();  // Prevents the default form submission    
const eduusername = document.getElementById('eduusername').value;
const eduemail = document.getElementById('eduemail').value;
const edupassword = document.getElementById('edupassword').value;
const educonfirmPassword = document.getElementById('educonfirmPassword').value;
const eduphone = document.getElementById('eduphone').value;
const eduagreeTerms = document.getElementById('eduagreeTerms').checked;

if (!eduusername || !eduemail || !edupassword || !educonfirmPassword || !eduphone) {
    alert("Please fill out all fields.");
    return;
}

if (edupassword !== educonfirmPassword) {
    alert("Passwords do not match.");
    return;
}

if (!eduagreeTerms) {
    alert("You must agree to the terms and conditions.");
    return;
}

alert("Signup successful! Data will be saved.");

// Ensure form submission happens after validation
document.getElementById('edusignupform').submit(); 
});

