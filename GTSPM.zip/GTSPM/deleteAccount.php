<?php
session_start();

$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "gtspm";

if (!isset($_SESSION['user_id'])) {
    die("Error: StudentID not set in session. Please log in again.");
}

$studentID = $_SESSION['user_id'];

// Connect to database
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete user data from the database
$sql = "DELETE FROM student WHERE StudentID = ?";
$stmt = $conn->prepare($sql);

if ($stmt) {
    $stmt->bind_param("s", $studentID);
    if ($stmt->execute()) {
        // Successfully deleted
        // Unset session data and redirect to homepage
        session_unset();
        session_destroy();
        header("Location: homepage.php?deleted=true");
        exit;
    } else {
        die("Error: Failed to delete account.");
    }
    $stmt->close();
} else {
    die("Error: SQL preparation failed.");
}

$conn->close();
?>
